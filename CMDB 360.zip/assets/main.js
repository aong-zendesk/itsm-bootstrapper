let client;

const htmlTemplates = {
  editButton: '<a class="action-btn edit-record" href="javascript:void(0)" uk-icon="icon: file-edit"></a>',
  updateButton: '<a class="action-btn update-record uk-hidden" href="javascript:void(0)" uk-icon="icon: check"></a>',
  cancelButton: '<a class="action-btn cancel-record uk-hidden" href="javascript:void(0)" uk-icon="icon: ban"></a>',
  deleteButton: '<a class="action-btn delete-record" href="javascript:void(0)" uk-icon="icon: trash"></a>',
  spinner: '<div class="spinner-load uk-hidden" uk-spinner></div>',
  select: '<select class="uk-select" value=""></select>',
  assignButton: '<button class="uk-button uk-button-default uk-button-small uk-hidden assign" style="background-color: #28A746; color: #fff">Assign</button>',
  unassignButton: '<button class="uk-button uk-button-danger uk-button-small uk-hidden unassign">Unassign</button>',
};

const generalFunctions = {
  getRowInputValue: (tr) => {    
    let rowArr = [];

    tr.find('td').each((index, elem) => {
      if($(elem).children('input')) {
        rowArr.push($(elem).children('input').val());
      }
    });

    return rowArr;
  },

  showMainSpinner: () => {
    $(window).scrollTop(0);
    $('.config').scrollLeft(0);
    $('#settings-loader').removeClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 0.05
    });
  },
  
  hideMainSpinner: () => {
    $('#settings-loader').addClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 1
    });
  },

  generateAlertMessage: ({ type, msg }) => {
    generalFunctions.removeAlertMessages();
    const alert = `<div class="uk-alert-${type}" uk-alert>\
    <a class="uk-alert-close" uk-close></a>\
    <p>${msg}</p></div>`;

    $('.config').prepend(alert);
  },

  removeAlertMessages: () => {
    $('.config div[uk-alert]').remove();
  },

  registerGeneralEventsHandlers: () => {
    $('.buttons-container .add-ci').on('click', async () => {
      const ticket = await client.get('ticket').then(({ ticket }) => { return ticket });
      const rowNumber = $('.config table tbody').find('tr').length + 1;

      let tableRow = `<tr class="new-row" data-row-number=${rowNumber}>\
      <td><input class="uk-input" type="text" value="" /></td>\
      <td><input class="uk-input" type="text" value="" /></td>\
      <td><input class="uk-input uk-hidden" type="text" />${htmlTemplates.assignButton}${htmlTemplates.unassignButton}</td>\
      <td>${htmlTemplates.deleteButton}</td></tr>`;
      $('.config table.user-related-requests tbody').append(tableRow);
      $(`.config table.user-related-requests tbody tr[data-row-number=${rowNumber}]`).find('.assign').removeClass('uk-hidden');
      
      $(`.config table.user-related-requests tbody tr[data-row-number=${rowNumber}]`).find('.assign').on('click', async () => {
        console.log('assign!');
        const button = $(event.currentTarget);
        generalFunctions.showMainSpinner();
        const ticket = await Promise.resolve(client.get('ticket')).then(({ ticket }) => { return ticket }, (err) => { return err });
        const showRequestObjectRecordPromise = sunshineApi.showObjectRecordByExternalId({ object_type: 'request', external_id: ticket.id });
        let showRequesterObjectRecordPromise = sunshineApi.showObjectRecordByExternalId({ object_type: 'requester', external_id: ticket.requester.id });

        const requestObjectRecord = await Promise.resolve(showRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
        let requesterObjectRecord = await Promise.resolve(showRequesterObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
        requesterObjectRecord = requesterObjectRecord[0];

        if(requestObjectRecord.length > 0) {
          generalFunctions.removeAlertMessages();
          generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You cannot assign another request to this ticket. There is already a request pending for approval. See Approvals app.' });
          generalFunctions.hideMainSpinner();
          return false;
        } else {
          let isChangeRequest = false;
  
          const listRequestTypesObjectRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'request_type' });
          const getTicketPromise = sunshineApi.sendApiRequest({ url: `/api/v2/tickets/${ticket.id}.json`, method: 'GET' });
  
          const requestTypes = await Promise.resolve(listRequestTypesObjectRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
          const customTicketFields = await Promise.resolve(getTicketPromise).then(({ ticket: { custom_fields }}) => { return custom_fields });
  
          let changeRequestType = requestTypes.find(({ attributes: { name }}) => {
            return name.includes('Change');
          });
  
          const changeTypeFormId = changeRequestType.attributes['ticket_form_id'];
  
          isChangeRequest = changeTypeFormId === ticket.form.id ? true : false;
  
          console.log(changeTypeFormId);
          console.log(ticket.form.id);
  
  
          if(!isChangeRequest) {
            generalFunctions.removeAlertMessages();
            generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You can only assign an item manually when requesting for a change.' });
            generalFunctions.hideMainSpinner();
          } else {
            const changeTypeFieldId = changeRequestType.attributes['ticket_field_id'];
  
            let changeTypeFieldValue = customTicketFields.find(({ id }) => {
              return id === changeTypeFieldId
            });
  
            changeTypeFieldValue = changeTypeFieldValue.value;
            
            console.log('changeTypeFieldValue:');
            console.log(changeTypeFieldValue);
  
  
            const requestType = requestTypes.find(({ attributes: { name }}) => {
              return name.toLowerCase() === `${changeTypeFieldValue} change`
            });
  
            const listRelatedAgentsToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: requestType.id, relationship_type: 'request_type_to_agent' });
            
            let newApprovalObjectRecordPayload = {
              data: {
                external_id: ticket.id,
                type: 'approval',
                attributes: {
                  status: 'Pending',
                  approver: {},
                  rejection_comment: ''
                }
              }
            };
  
            if(requestType.attributes.name === 'Standard Change') {
              const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });
  
              newApprovalObjectRecordPayload.data.attributes.status = 'Approved';
              newApprovalObjectRecordPayload.data.attributes.approver = {
                id: currentUser.id,
                name: currentUser.name,
                email: currentUser.email
              };
            }
  
            const createNewApprovalObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newApprovalObjectRecordPayload });
  
            const newRequestObjectRecordPayload = {
              data: {
                external_id: ticket.id,
                type: 'request',
                attributes: {
                  type: 'change'
                }
              }
            };
  
            const createNewRequestObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newRequestObjectRecordPayload });

            let item = {};

            button.parent().siblings().each((index, elem) => {
              if(index === 0) {
                item.type = $(elem).find('input').val();
              }

              if(index === 1) {
                item.model = $(elem).find('input').val();
              }
            });

            console.log('item:');
            console.log(item);

            const newItemObjectRecordPayload = {
              data: {
                type: 'item',
                attributes: {
                  type: item.type,
                  model: item.model
                }
              }
            };
      
            const createNewItemObjectRecordPromise = sunshineApi.createObjectRecord({ payload: newItemObjectRecordPayload });
              
            const newApprovalObjectRecord = await Promise.resolve(createNewApprovalObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
            const newRequestObjectRecord = await Promise.resolve(createNewRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
            const itemObjectRecord = await Promise.resolve(createNewItemObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
            
            const requesterToItemPayload = {
              data: {
                relationship_type: 'requester_to_item',
                source: requesterObjectRecord.id,
                target: itemObjectRecord.id
              }
            };
      
            const createRequesterToItemRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requesterToItemPayload });
            
            const itemToRequesterPayload = {
              data: {
                relationship_type: 'item_to_requester',
                source: itemObjectRecord.id,
                target: requesterObjectRecord.id
              }
            };
      
            const createItemToRequesterRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: itemToRequesterPayload }); 

            const requestToRequesterPayload = {
              data: {
                relationship_type: 'request_to_requester',
                source: newRequestObjectRecord.id,
                target: requesterObjectRecord.id
              }
            };
      
            const createRequestToRequesterRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequesterPayload });
  
            const requesterToRequestPayload = {
              data: {
                relationship_type: 'requester_to_request',
                source: requesterObjectRecord.id,
                target: newRequestObjectRecord.id
              }
            };
      
            const createRequesterToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requesterToRequestPayload });
  
            const requestToItemPayload = {
              data: {
                relationship_type: 'request_to_item',
                source: newRequestObjectRecord.id,
                target: itemObjectRecord.id
              }
            };
      
            const createRequestToItemRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToItemPayload });
  
            const itemToRequestPayload = {
              data: {
                relationship_type: 'item_to_request',
                source: itemObjectRecord.id,
                target: newRequestObjectRecord.id
              }
            };
      
            const createItemToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: itemToRequestPayload });
  
            const requestToApprovalPayload = {
              data: {
                relationship_type: 'request_to_approval',
                source: newRequestObjectRecord.id,
                target: newApprovalObjectRecord.id
              }
            };
      
            const createRequestToApprovalRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToApprovalPayload });
  
            const approvalToRequestPayload = {
              data: {
                relationship_type: 'approval_to_request',
                source: newApprovalObjectRecord.id,
                target: newRequestObjectRecord.id
              }
            };
      
            const createApprovalToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: approvalToRequestPayload });
  
            const requestToRequestTypePayload = {
              data: {
                relationship_type: 'request_to_request_type',
                source: newRequestObjectRecord.id,
                target: requestType.id
              }
            };
      
            const createRequestToRequestTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequestTypePayload });
  
            const requestTypeToRequestPayload = {
              data: {
                relationship_type: 'request_type_to_request',
                source: requestType.id,
                target: newRequestObjectRecord.id
              }
            };
      
            const createRequestTypeToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestTypeToRequestPayload });
  
            await Promise.all([
              createRequesterToItemRelationshipRecordPromise, 
              createItemToRequesterRelationshipRecordPromise,
              createRequestToRequesterRelationshipRecordPromise, 
              createRequesterToRequestRelationshipRecordPromise, 
              createRequestToItemRelationshipRecordPromise, 
              createItemToRequestRelationshipRecordPromise, 
              createRequestToApprovalRelationshipRecordPromise, 
              createApprovalToRequestRelationshipRecordPromise, 
              createRequestToRequestTypeRelationshipRecordPromise, 
              createRequestTypeToRequestRelationshipRecordPromise]);
            
            const relatedAgentsToRequestType = await Promise.resolve(listRelatedAgentsToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });
  
            let approversList = [];
            relatedAgentsToRequestType.map(({ attributes: { email }}) => {
              approversList.push(email);
            });
  
            if(requestType.attributes.name === 'Standard Change') {
              const listTaskObjectRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'task' });
              const taskTypeObjectRecords = await sunshineApi.listObjectRecordsByType({ object_type: 'task_type' }).then(({ data }) => { return data }, (err) => { return err });
  
              const fulfillmentTaskType = taskTypeObjectRecords.find(({ attributes: { name } }) => {
                return name === 'Fulfillment'
              });
      
              const fulfillmentTaskTypeToAgentObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: fulfillmentTaskType.id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });
              let fulfillmentTaskFulfillerList = [];
              
              fulfillmentTaskTypeToAgentObjectRecords.map(({ attributes: { email }}) => {
                fulfillmentTaskFulfillerList.push(email);
              });
      
              let internalNoteForFulfillmentTicketPayload = {
                ticket: {
                  subject: 'Fulfillment task',
                  comment: { 
                    html_body: `This is a fulfillment task for ticket <a href="/agent/tickets/${ticket.id}">#${ticket.id}</a>. Please see Task app for more details.`, 
                    body: `This is a fulfillment task for ticket ${ticket.id}`,
                    public: false
                  }
                }
              };
      
              const fulfillmentTicketSettings = {
                headers: {
                  'Content-Type': 'application/json'
                },
                url: '/api/v2/tickets',
                method: 'POST',
                data: JSON.stringify(internalNoteForFulfillmentTicketPayload)
              }
        
              const fulfillmentTicket = await client.request(fulfillmentTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });
      
              let internalNoteForCurrentTicketPayload = {
                ticket: {
                  comment: { 
                    body: `A Fulfillment task has been generated for this request. Please see ticket #${fulfillmentTicket.id}. \n\nWaiting on the following fulfillers\' action: \n - ${fulfillmentTaskFulfillerList.join('\n - ')}`,
                    html_body: `A Fulfillment task has been generated for this request. Please see ticket <a href="/agent/tickets/${fulfillmentTicket.id}">#${fulfillmentTicket.id}</a>.<br><br>Waiting on the following fulfillers\' action: <br> <ul><li> ${fulfillmentTaskFulfillerList.join('</li><li>')} </li></ul>`,
                    public: false
                  }
                }
              };
                
              const currentTicketSettings = {
                headers: {
                  'Content-Type': 'application/json'
                },
                url: `/api/v2/tickets/${ticket.id}.json`,
                method: 'PUT',
                data: JSON.stringify(internalNoteForCurrentTicketPayload)
              }
          
              await client.request(currentTicketSettings);
  
              taskObjectRecords = await Promise.resolve(listTaskObjectRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
  
              let taskPayload = {
                data: {
                  external_id: fulfillmentTicket.id,
                  type: 'task',
                  attributes: {
                    task_id: taskObjectRecords.length + 1001,
                    status: 'New',
                    fulfiller: {}
                  }
                }
              };
              
              console.log('taskPayload:');
              console.log(taskPayload);
      
              const fulfillmentTaskObjectRecord = await sunshineApi.createObjectRecord({ payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });
              
              const fulfillmentTaskToRequestPayload = {
                data: {
                  relationship_type: 'task_to_request',
                  source: fulfillmentTaskObjectRecord.id,
                  target: newRequestObjectRecord.id
                }
              };
      
              const createFulfillmentTaskToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToRequestPayload });
      
              const requestToFulfillmentTaskPayload = {
                data: {
                  relationship_type: 'request_to_task',
                  source: newRequestObjectRecord.id,
                  target: fulfillmentTaskObjectRecord.id
                }
              };
      
              const createRequestToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToFulfillmentTaskPayload });
      
              const fulfillmentTaskToTaskTypePayload = {
                data: {
                  relationship_type: 'task_to_task_type',
                  source: fulfillmentTaskObjectRecord.id,
                  target: fulfillmentTaskType.id
                }
              };
      
              const createFulfillmentTaskToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToTaskTypePayload });
      
              const taskTypeToFulfillmentTaskPayload = {
                data: {
                  relationship_type: 'task_type_to_task',
                  source: fulfillmentTaskType.id,
                  target: fulfillmentTaskObjectRecord.id
                }
              };
      
              const createTaskTypeToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToFulfillmentTaskPayload });
      
              await Promise.all([
                createFulfillmentTaskToRequestRelationshipRecordPromise, 
                createRequestToFulfillmentTaskRelationshipRecordPromise, 
                createFulfillmentTaskToTaskTypeRelationshipRecordPromise, 
                createTaskTypeToFulfillmentTaskRelationshipRecordPromise
              ]);
            } else {
              const internalNote = {
                ticket: {
                  comment: { 
                    body: `An approval request has been generated for this ticket. Please reload the Approvals app. \n\nWaiting on the following approvers\' action: \n - ${approversList.join('\n - ')}`,
                    html_body: `An approval request has been generated on this ticket. Please reload the <strong>Approvals</strong> app.<br><br>Waiting on the following approvers\' action: <br> <ul><li> ${approversList.join('</li><li>')} </li></ul>`, 
                    public: false
                  }
                }
              };
  
              const settings = {
                headers: {
                  'Content-Type': 'application/json'
                },
                url: `/api/v2/tickets/${ticket.id}.json`,
                method: 'PUT',
                data: JSON.stringify(internalNote)
              }
        
              await client.request(settings);
            }
          }
        }

        generalFunctions.removeAlertMessages();
        generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully assigned item to this ticket' });
        const relatedItemsToRequesterObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requesterObjectRecord.id, relationship_type: 'requester_to_item' }).then(({ data }) => { return data }, (error) => { return error });
        await generalFunctions.refreshTableRows({ itemList: relatedItemsToRequesterObjectRecords, ticketId: ticket.id });
        generalFunctions.hideMainSpinner();
      });

      $(`.config table.user-related-requests tbody tr[data-row-number=${rowNumber}]`).find('.delete-record').on('click', () => {
        $(event.currentTarget).parents('tr').remove();
      });
    });
  },

  registerTableEventsHandlers: () => {
    $('.config button.assign').on('click', async () => {
      const button = $(event.currentTarget);

      generalFunctions.showMainSpinner();
      const ticket = await client.get('ticket').then(({ ticket }) => { return ticket });

      let requesterObjectRecord = await sunshineApi.showObjectRecordByExternalId({ object_type: 'requester', external_id: ticket.requester.id }).then(({ data }) => { return data });
      requesterObjectRecord = requesterObjectRecord[0];

      button.addClass('uk-hidden');
      button.siblings('button').removeClass('uk-hidden');

      const assignedRequestsList = $('table.ticket-related-requests tbody tr td');

      if(assignedRequestsList.length > 0) {
        generalFunctions.removeAlertMessages();
        generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You cannot assign another request to this ticket. Please remove the currently assigned request first and try again.' });
        generalFunctions.hideMainSpinner();
        return false;
      } else {
        let isChangeRequest = false;

        const listRequestTypesObjectRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'request_type' });
        const getTicketPromise = sunshineApi.sendApiRequest({ url: `/api/v2/tickets/${ticket.id}.json`, method: 'GET' });

        const requestTypes = await Promise.resolve(listRequestTypesObjectRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
        const customTicketFields = await Promise.resolve(getTicketPromise).then(({ ticket: { custom_fields }}) => { return custom_fields });

        let changeRequestType = requestTypes.find(({ attributes: { name }}) => {
          return name.includes('Change');
        });

        const changeTypeFormId = changeRequestType.attributes['ticket_form_id'];

        isChangeRequest = changeTypeFormId === ticket.form.id ? true : false;

        console.log(changeTypeFormId);
        console.log(ticket.form.id);


        if(!isChangeRequest) {
          generalFunctions.removeAlertMessages();
          generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You can only assign an item manually when requesting for a change.' });
          generalFunctions.hideMainSpinner();
        } else {
          const changeTypeFieldId = changeRequestType.attributes['ticket_field_id'];

          let changeTypeFieldValue = customTicketFields.find(({ id }) => {
            return id === changeTypeFieldId
          });

          changeTypeFieldValue = changeTypeFieldValue.value;

          console.log(changeTypeFieldValue);


          const requestType = requestTypes.find(({ attributes: { name }}) => {
            return name.toLowerCase() === `${changeTypeFieldValue} change`
          });

          const listRelatedAgentsToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: requestType.id, relationship_type: 'request_type_to_agent' });
          
          let newApprovalObjectRecordPayload = {
            data: {
              external_id: ticket.id,
              type: 'approval',
              attributes: {
                status: 'Pending',
                approver: {},
                rejection_comment: ''
              }
            }
          };

          if(requestType.attributes.name === 'Standard Change') {
            const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });

            newApprovalObjectRecordPayload.data.attributes.status = 'Approved';
            newApprovalObjectRecordPayload.data.attributes.approver = {
              id: currentUser.id,
              name: currentUser.name,
              email: currentUser.email
            };
          }

          const createNewApprovalObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newApprovalObjectRecordPayload });

          const newRequestObjectRecordPayload = {
            data: {
              external_id: ticket.id,
              type: 'request',
              attributes: {
                type: 'change'
              }
            }
          };

          const createNewRequestObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newRequestObjectRecordPayload });
          
          const itemId = button.parents('tr').attr('data-item-id');
          const showItemObjectRecordPromise = sunshineApi.showObjectRecord({ id: itemId });

          const newApprovalObjectRecord = await Promise.resolve(createNewApprovalObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
          const newRequestObjectRecord = await Promise.resolve(createNewRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
          const itemObjectRecord = await Promise.resolve(showItemObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });

          const requestToRequesterPayload = {
            data: {
              relationship_type: 'request_to_requester',
              source: newRequestObjectRecord.id,
              target: requesterObjectRecord.id
            }
          };
    
          const createRequestToRequesterRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequesterPayload });

          const requesterToRequestPayload = {
            data: {
              relationship_type: 'requester_to_request',
              source: requesterObjectRecord.id,
              target: newRequestObjectRecord.id
            }
          };
    
          const createRequesterToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requesterToRequestPayload });

          const requestToItemPayload = {
            data: {
              relationship_type: 'request_to_item',
              source: newRequestObjectRecord.id,
              target: itemObjectRecord.id
            }
          };
    
          const createRequestToItemRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToItemPayload });

          const itemToRequestPayload = {
            data: {
              relationship_type: 'item_to_request',
              source: itemObjectRecord.id,
              target: newRequestObjectRecord.id
            }
          };
    
          const createItemToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: itemToRequestPayload });

          const requestToApprovalPayload = {
            data: {
              relationship_type: 'request_to_approval',
              source: newRequestObjectRecord.id,
              target: newApprovalObjectRecord.id
            }
          };
    
          const createRequestToApprovalRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToApprovalPayload });

          const approvalToRequestPayload = {
            data: {
              relationship_type: 'approval_to_request',
              source: newApprovalObjectRecord.id,
              target: newRequestObjectRecord.id
            }
          };
    
          const createApprovalToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: approvalToRequestPayload });

          const requestToRequestTypePayload = {
            data: {
              relationship_type: 'request_to_request_type',
              source: newRequestObjectRecord.id,
              target: requestType.id
            }
          };
    
          const createRequestToRequestTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequestTypePayload });

          const requestTypeToRequestPayload = {
            data: {
              relationship_type: 'request_type_to_request',
              source: requestType.id,
              target: newRequestObjectRecord.id
            }
          };
    
          const createRequestTypeToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestTypeToRequestPayload });

          await Promise.all([createRequestToRequesterRelationshipRecordPromise, createRequesterToRequestRelationshipRecordPromise, createRequestToItemRelationshipRecordPromise, createItemToRequestRelationshipRecordPromise, createRequestToApprovalRelationshipRecordPromise, createApprovalToRequestRelationshipRecordPromise, createRequestToRequestTypeRelationshipRecordPromise, createRequestTypeToRequestRelationshipRecordPromise]);
          
          const relatedAgentsToRequestType = await Promise.resolve(listRelatedAgentsToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });

          let approversList = [];
          relatedAgentsToRequestType.map(({ attributes: { email }}) => {
            approversList.push(email);
          });

          if(requestType.attributes.name === 'Standard Change') {
            const listTaskObjectRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'task' });
            const taskTypeObjectRecords = await sunshineApi.listObjectRecordsByType({ object_type: 'task_type' }).then(({ data }) => { return data }, (err) => { return err });

            const fulfillmentTaskType = taskTypeObjectRecords.find(({ attributes: { name } }) => {
              return name === 'Fulfillment'
            });
    
            const fulfillmentTaskTypeToAgentObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: fulfillmentTaskType.id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });
            let fulfillmentTaskFulfillerList = [];
            
            fulfillmentTaskTypeToAgentObjectRecords.map(({ attributes: { email }}) => {
              fulfillmentTaskFulfillerList.push(email);
            });
    
            let internalNoteForFulfillmentTicketPayload = {
              ticket: {
                subject: 'Fulfillment task',
                comment: { 
                  html_body: `This is a fulfillment task for ticket <a href="/agent/tickets/${ticket.id}">#${ticket.id}</a>. Please see Task app for more details.`, 
                  body: `This is a fulfillment task for ticket ${ticket.id}`,
                  public: false
                }
              }
            };
    
            const fulfillmentTicketSettings = {
              headers: {
                'Content-Type': 'application/json'
              },
              url: '/api/v2/tickets',
              method: 'POST',
              data: JSON.stringify(internalNoteForFulfillmentTicketPayload)
            }
      
            const fulfillmentTicket = await client.request(fulfillmentTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });
    
            let internalNoteForCurrentTicketPayload = {
              ticket: {
                comment: { 
                  body: `A Fulfillment task has been generated for this request. Please see ticket #${fulfillmentTicket.id}. \n\nWaiting on the following fulfillers\' action: \n - ${fulfillmentTaskFulfillerList.join('\n - ')}`,
                  html_body: `A Fulfillment task has been generated for this request. Please see ticket <a href="/agent/tickets/${fulfillmentTicket.id}">#${fulfillmentTicket.id}</a>.<br><br>Waiting on the following fulfillers\' action: <br> <ul><li> ${fulfillmentTaskFulfillerList.join('</li><li>')} </li></ul>`,
                  public: false
                }
              }
            };
              
            const currentTicketSettings = {
              headers: {
                'Content-Type': 'application/json'
              },
              url: `/api/v2/tickets/${ticket.id}.json`,
              method: 'PUT',
              data: JSON.stringify(internalNoteForCurrentTicketPayload)
            }
        
            await client.request(currentTicketSettings);

            taskObjectRecords = await Promise.resolve(listTaskObjectRecordsPromise).then(({ data }) => { return data }, (err) => { return err });

            let taskPayload = {
              data: {
                external_id: fulfillmentTicket.id,
                type: 'task',
                attributes: {
                  task_id: taskObjectRecords.length + 1001,
                  status: 'New',
                  fulfiller: {}
                }
              }
            };
            
            console.log('taskPayload:');
            console.log(taskPayload);
    
            const fulfillmentTaskObjectRecord = await sunshineApi.createObjectRecord({ payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });
            
            const fulfillmentTaskToRequestPayload = {
              data: {
                relationship_type: 'task_to_request',
                source: fulfillmentTaskObjectRecord.id,
                target: newRequestObjectRecord.id
              }
            };
    
            const createFulfillmentTaskToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToRequestPayload });
    
            const requestToFulfillmentTaskPayload = {
              data: {
                relationship_type: 'request_to_task',
                source: newRequestObjectRecord.id,
                target: fulfillmentTaskObjectRecord.id
              }
            };
    
            const createRequestToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToFulfillmentTaskPayload });
    
            const fulfillmentTaskToTaskTypePayload = {
              data: {
                relationship_type: 'task_to_task_type',
                source: fulfillmentTaskObjectRecord.id,
                target: fulfillmentTaskType.id
              }
            };
    
            const createFulfillmentTaskToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToTaskTypePayload });
    
            const taskTypeToFulfillmentTaskPayload = {
              data: {
                relationship_type: 'task_type_to_task',
                source: fulfillmentTaskType.id,
                target: fulfillmentTaskObjectRecord.id
              }
            };
    
            const createTaskTypeToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToFulfillmentTaskPayload });
    
            await Promise.all([
              createFulfillmentTaskToRequestRelationshipRecordPromise, 
              createRequestToFulfillmentTaskRelationshipRecordPromise, 
              createFulfillmentTaskToTaskTypeRelationshipRecordPromise, 
              createTaskTypeToFulfillmentTaskRelationshipRecordPromise
            ]);
          } else {
            const internalNote = {
              ticket: {
                comment: { 
                  body: `An approval request has been generated for this ticket. Please reload the Approvals app. \n\nWaiting on the following approvers\' action: \n - ${approversList.join('\n - ')}`,
                  html_body: `An approval request has been generated on this ticket. Please reload the <strong>Approvals</strong> app.<br><br>Waiting on the following approvers\' action: <br> <ul><li> ${approversList.join('</li><li>')} </li></ul>`, 
                  public: false
                }
              }
            };

            const settings = {
              headers: {
                'Content-Type': 'application/json'
              },
              url: `/api/v2/tickets/${ticket.id}.json`,
              method: 'PUT',
              data: JSON.stringify(internalNote)
            }
      
            await client.request(settings);
          }
        }
      }

      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully assigned item to this ticket' });
      const relatedItemsToRequesterObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requesterObjectRecord.id, relationship_type: 'requester_to_item' }).then(({ data }) => { return data }, (error) => { return error });
      await generalFunctions.refreshTableRows({ itemList: relatedItemsToRequesterObjectRecords, ticketId: ticket.id });
      generalFunctions.hideMainSpinner();
    });

    $('.config button.unassign').on('click', async () => {
      const button = $(event.currentTarget);

      generalFunctions.showMainSpinner();

      button.addClass('uk-hidden');
      button.siblings('button').removeClass('uk-hidden');
      
      const itemId = button.parents('tr').attr('data-item-id');
      
      const getTicketPromise = client.get('ticket');
      const showItemObjectRecordPromise = sunshineApi.showObjectRecord({ id: itemId });

      const ticket = await Promise.resolve(getTicketPromise).then(({ ticket }) => { return ticket });
      const showRequestObjectRecordPromise = sunshineApi.showObjectRecordByExternalId({ object_type: 'request', external_id: ticket.id });
      const showRequesterObjectRecordPromise = sunshineApi.showObjectRecordByExternalId({ object_type: 'requester', external_id: ticket.requester.id });

      const itemObjectRecord = await Promise.resolve(showItemObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      let requestObjectRecord = await Promise.resolve(showRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      requestObjectRecord = requestObjectRecord[0];
      let requesterObjectRecord = await Promise.resolve(showRequesterObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      requesterObjectRecord = requesterObjectRecord[0];



      const listRequestToItemRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestObjectRecord.id, relationship_type: 'request_to_item' });
      const listItemToRequestRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByObjectRecord({ id: itemObjectRecord.id, relationship_type: 'item_to_request' });
      const listRequestToRequesterRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestObjectRecord.id, relationship_type: 'request_to_requester' });
      const listRequesterToRequestRelationshipRecords = sunshineApi.listRelationshipRecordsByObjectRecord({ id: requesterObjectRecord.id, relationship_type: 'requester_to_request' });
      const listRequestToRequestTypeRelationshipRecord = sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestObjectRecord.id, relationship_type: 'request_to_request_type' });
      const listRequestToApprovalRelationshipRecord = sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestObjectRecord.id, relationship_type: 'request_to_approval' });

      const requestToItemRelationshipRecords = await Promise.resolve(listRequestToItemRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
      const requestToItemRelationshipRecord = requestToItemRelationshipRecords.find(({ target }) => {
        return target === itemObjectRecord.id;
      });

      const itemToRequestRelationshipRecords = await Promise.resolve(listItemToRequestRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
      const itemToRequestRelationshipRecord = itemToRequestRelationshipRecords.find(({ target }) => {
        return target === requestObjectRecord.id;
      });

      const requestToRequesterRelationshipRecords = await Promise.resolve(listRequestToRequesterRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
      const requestToRequesterRelationshipRecord = requestToRequesterRelationshipRecords.find(({ target }) => {
        return target === requesterObjectRecord.id;
      });

      const requesterToRequestRelationshipRecords = await Promise.resolve(listRequesterToRequestRelationshipRecords).then(({ data }) => { return data }, (err) => { return err });
      const requesterToRequestRelationshipRecord = requesterToRequestRelationshipRecords.find(({ target }) => {
        return target === requestObjectRecord.id;
      });

      let requestToRequestTypeRelationshipRecord = await Promise.resolve(listRequestToRequestTypeRelationshipRecord).then(({ data }) => { return data }, (err) => { return err });
      requestToRequestTypeRelationshipRecord = requestToRequestTypeRelationshipRecord[0];

      let requestTypeToRequestRelationshipRecord = await sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestToRequestTypeRelationshipRecord.target, relationship_type: 'request_type_to_request' }).then(({ data }) => { return data }, (err) => { return err });
      requestTypeToRequestRelationshipRecord = requestTypeToRequestRelationshipRecord[0];

      let requestToApprovalRelationshipRecord = await Promise.resolve(listRequestToApprovalRelationshipRecord).then(({ data }) => { return data }, (err) => { return err });
      requestToApprovalRelationshipRecord = requestToApprovalRelationshipRecord[0];
      
      let approvalToRequestRelationshipRecord = await sunshineApi.listRelationshipRecordsByObjectRecord({ id: requestToApprovalRelationshipRecord.target, relationship_type: 'approval_to_request' }).then(({ data }) => { return data }, (err) => { return err });
      approvalToRequestRelationshipRecord = approvalToRequestRelationshipRecord[0];

      const deleteRequestToItemRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requestToItemRelationshipRecord.id });
      const deleteItemToRequestRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: itemToRequestRelationshipRecord.id });
      const deleteRequestToRequesterRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requestToRequesterRelationshipRecord.id });
      const deleteRequesterToRequestRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requesterToRequestRelationshipRecord.id });
      const deleteRequestToRequestTypeRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requestToRequestTypeRelationshipRecord.id });
      const deleteRequestTypeToRequestRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requestTypeToRequestRelationshipRecord.id });
      const deleteRequestToApprovalRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: requestToApprovalRelationshipRecord.id });
      const deleteApprovalToRequestRelationshipRecordPromise = sunshineApi.deleteRelationshipRecord({ id: approvalToRequestRelationshipRecord.id });

      await Promise.all([deleteRequestToItemRelationshipRecordPromise, deleteItemToRequestRelationshipRecordPromise, deleteRequestToRequesterRelationshipRecordPromise, deleteRequesterToRequestRelationshipRecordPromise, deleteRequestToRequestTypeRelationshipRecordPromise, deleteRequestTypeToRequestRelationshipRecordPromise, deleteRequestToApprovalRelationshipRecordPromise, deleteApprovalToRequestRelationshipRecordPromise]);
      
      const deleteRequestObjectRecordPromise = sunshineApi.deleteObjectRecord({ id: requestObjectRecord.id });
      const deleteApprovalObjectRecordPromise = sunshineApi.deleteObjectRecord({ id: requestToApprovalRelationshipRecord.target });
      
      await Promise.all([deleteRequestObjectRecordPromise, deleteApprovalObjectRecordPromise]);

      const internalNote = {
        ticket: {
          comment: { 
            body: 'A previous approval request has been removed from this ticket.',
            html_body: 'A previous approval request has been removed from this ticket.', 
            public: false
          }
        }
      };

      const settings = {
        headers: {
          'Content-Type': 'application/json'
        },
        url: `/api/v2/tickets/${ticket.id}.json`,
        method: 'PUT',
        data: JSON.stringify(internalNote)
      }

      await client.request(settings);

      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully removed request from this ticket' });
      const relatedItemsToRequesterObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requesterObjectRecord.id, relationship_type: 'requester_to_item' }).then(({ data }) => { return data }, (error) => { return error });
      await generalFunctions.refreshTableRows({ itemList: relatedItemsToRequesterObjectRecords, ticketId: ticket.id });
      generalFunctions.hideMainSpinner();
    });

    $('.config a.edit-record').on('click', async () => {
      $(event.currentTarget).parent('td').css({ 'min-width': '50px' });
      $(event.currentTarget).addClass('uk-hidden');
      $(event.currentTarget).siblings('.update-record, .cancel-record').removeClass('uk-hidden');

      $(event.currentTarget).parent('td').siblings('td').each((index, elem) => {
        $(elem).children('input').removeClass('uk-hidden');
        $(elem).children('p').addClass('uk-hidden');
      });
    });

    $('.config a.update-record').on('click', async () => {
      const button = $(event.currentTarget);
      
      button.parent('td').css({ 'min-width': '20px' });
      button.siblings().addBack().addClass('uk-hidden');
      button.siblings('.edit-record').removeClass('uk-hidden');

      let item = {};

      button.parent('td').siblings('td').each((index, elem) => {
        if(index === 0) {
          item.type = $(elem).children('input').val();
        }

        if(index === 1) {
          item.model = $(elem).children('input').val();
        }

        $(elem).children('input').addClass('uk-hidden');
        $(elem).children('p').removeClass('uk-hidden');
      });

      const itemId = $(event.currentTarget).parents('tr').attr('data-item-id');

      const payload = {
        data: {
          type: 'item',
          attributes: {
            type: item.type,
            model: item.model
          }
        }
      };

      await sunshineApi.updateObjectRecord({ id: itemId, payload }).then(({ data }) => { return data }, (err) => { return err });

      console.log('done!');

      button.parent('td').siblings('td').each((index, elem) => {
        console.log(index);
        console.log(elem);
        if(index === 0) {
          $(elem).children('p').html(item.type);
        }

        if(index === 1) {
          $(elem).children('p').html(item.model);
        }
      });
    });

    $('.config a.cancel-record').on('click', async () => {
      $(event.currentTarget).parent('td').css({ 'min-width': '20px' });
      $(event.currentTarget).siblings().addBack().addClass('uk-hidden');
      $(event.currentTarget).siblings('.edit-record').removeClass('uk-hidden');

      $(event.currentTarget).parent('td').siblings('td').each((index, elem) => {
        $(elem).children('p').removeClass('uk-hidden');
        $(elem).children('input').addClass('uk-hidden');
      });
    });
  },

  unRegisterTableEventsHandlers: () => {
    $('.config table button').off();
    $('.config table select').off();
    $('.config table a').off();
  },

  refreshTableRows: async ({ itemList }) => {  
    console.log(itemList);

    generalFunctions.unRegisterTableEventsHandlers();
    $('.config table.ticket-related-requests tbody, .config table.user-related-requests tbody').empty();

    const ticket = await Promise.resolve(client.get('ticket')).then(({ ticket }) => { return ticket });

    const createRowPromises = itemList.map(async ({ id, attributes: { type, model }}) => {

      const relatedRequestsToItemObjectRecords = await sunshineApi.listRelatedObjectRecords({ id, relationship_type: 'item_to_request' }).then(({ data }) => { return data }, (err) => { return err });
      console.log(relatedRequestsToItemObjectRecords);

      let fulfilledItem = true;
      let relatedRequestObjectRecord = {};

      const findIncompleteTasksPromises = relatedRequestsToItemObjectRecords.map(async (request) => {
        if(request.attributes.type === 'new') {
          const relatedTaskToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: request.id, relationship_type: 'request_to_task' }).then(({ data }) => { return data }, (err) => { return err });
          
          if(relatedTaskToRequestObjectRecords.length < 1) {
            fulfilledItem = false;
            return;
          }

          const incompleteTask = relatedTaskToRequestObjectRecords.find(({ attributes: { status }}) => {
            return status !== 'Completed';
          });

          fulfilledItem = !incompleteTask ? true : false;
        }

        if(Number(request['external_id']) === ticket.id) {
          relatedRequestObjectRecord = request;
        }
      });

      await Promise.all(findIncompleteTasksPromises);

      if(fulfilledItem) {
        let tableRow = `<tr data-item-id="${id}">\
        <td><input class="uk-input uk-hidden" type="text" value="${type}" /><p>${type}</p></td>\
        <td><input class="uk-input uk-hidden" type="text" value="${model}" /><p>${model}</p></td>\
        <td>${htmlTemplates.assignButton}${htmlTemplates.unassignButton}</td>\
        <td>${htmlTemplates.editButton}${htmlTemplates.updateButton}${htmlTemplates.cancelButton}</td></tr>`;

        let assignButton = '';
        
        if(Number(relatedRequestObjectRecord['external_id']) === ticket.id) {
          $('.config table.ticket-related-requests tbody').append(tableRow);
          assignButton = 'unassign';
        } else {
          $('.config table.user-related-requests tbody').append(tableRow);
          assignButton = 'assign';
        }

        $(`.config table tbody tr[data-item-id="${id}"]`).find('button').siblings('input').val(relatedRequestObjectRecord['external_id']);
        $(`.config table tbody tr[data-item-id="${id}"]`).find(`.${assignButton}`).removeClass('uk-hidden');
      }
    });

    await Promise.all(createRowPromises);
    generalFunctions.registerTableEventsHandlers(); 
  }
}

const init = async () => {
  await Promise.resolve($());
  generalFunctions.showMainSpinner();
  client = await Promise.resolve(ZAFClient.init());
  await Promise.resolve(client.on('app.registered'));
  await Promise.resolve(client.invoke('resize', { width: '100%', height: '50vh' }));

  // Get ticket object
  const ticket = await Promise.resolve(client.get('ticket')).then(({ ticket }) => { return ticket }, (err) => { return err });
  
  const newRequesterObjectRecordPayload = {
    data: {
      type: 'requester',
      external_id: ticket.requester.id,
      attributes: {
        name: ticket.requester.name,
        email: ticket.requester.email,
      }
    }
  };
  
  // If `requester` CO record does not exist, create it. Pass the ticket requester's id as the value of `external_id attribute.
  const newRequesterObjectRecord = await sunshineApi.setObjectRecordByExternalId({ payload: newRequesterObjectRecordPayload }).then(({ data }) => { return data }, (err) => { return err });
  
  // Get all `request` CO records related to `requester`
  const relatedRequestsToRequesterObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: newRequesterObjectRecord.id, relationship_type: 'requester_to_request' }).then(({ data }) => { return data }, (error) => { return error });

  let hasExistingRequest = false;

  if(relatedRequestsToRequesterObjectRecords.length > 0) {
    // Find if there is an existing `request` CO record related to current ticket
    relatedRequestsToRequesterObjectRecords.map(({ external_id }) => {
      if(Number(external_id) === ticket.id) {
        hasExistingRequest = true;
      }
    });
  }

  if(!hasExistingRequest) {    
    const requestTypesObjectRecords = await sunshineApi.listObjectRecordsByType({ object_type: 'request_type' }).then(({ data }) => { return data }, (err) => { return err });
    const serviceCatalogRequestType = requestTypesObjectRecords.find(({ attributes: { name }}) => {
      return name === 'Hardware Request';
    });

    let serviceCatalogFieldValue = await Promise.resolve(client.get(`ticket.customField:custom_field_${serviceCatalogRequestType.attributes['ticket_field_id']}`));
    serviceCatalogFieldValue = !serviceCatalogFieldValue[`ticket.customField:custom_field_${serviceCatalogRequestType.attributes['ticket_field_id']}`] ? '' : serviceCatalogFieldValue[`ticket.customField:custom_field_${serviceCatalogRequestType.attributes['ticket_field_id']}`].split('__');

    if(ticket.form.id === serviceCatalogRequestType.attributes['ticket_form_id'] && serviceCatalogFieldValue) {
       
      let itemType = serviceCatalogFieldValue[0][0].toUpperCase() + serviceCatalogFieldValue[0].slice(1);
      let itemModel = serviceCatalogFieldValue[1][0].toUpperCase() + serviceCatalogFieldValue[1].slice(1).replace(/_/g, ' ');

      if(serviceCatalogFieldValue.length > 2) {
        itemType = serviceCatalogFieldValue[1][0].toUpperCase() + serviceCatalogFieldValue[1].slice(1).replace(/_/g, ' ');
        itemModel = serviceCatalogFieldValue[2][0].toUpperCase() + serviceCatalogFieldValue[2].slice(1).replace(/_/g, ' ')
      }

      const requestType = requestTypesObjectRecords.find(({ attributes: { name }}) => {
        return name === `${serviceCatalogFieldValue[0][0].toUpperCase() + serviceCatalogFieldValue[0].slice(1)} Request`;
      });

      const listRelatedAgentsToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: requestType.id, relationship_type: 'request_type_to_agent' });

      const newApprovalObjectRecordPayload = {
        data: {
          external_id: ticket.id,
          type: 'approval',
          attributes: {
            status: 'Pending',
            approver: {},
            rejection_comment: ''
          }
        }
      };

      const createNewApprovalObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newApprovalObjectRecordPayload });

      const newRequestObjectRecordPayload = {
        data: {
          external_id: ticket.id,
          type: 'request',
          attributes: {
            type: 'new'
          }
        }
      };

      const createNewRequestObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: newRequestObjectRecordPayload });

      const newItemObjectRecordPayload = {
        data: {
          type: 'item',
          attributes: {
            type: itemType,
            model: itemModel
          }
        }
      };

      const createNewItemObjectRecordPromise = sunshineApi.createObjectRecord({ payload: newItemObjectRecordPayload });

      const newApprovalObjectRecord = await Promise.resolve(createNewApprovalObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      const newRequestObjectRecord = await Promise.resolve(createNewRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      const newItemObjectRecord = await Promise.resolve(createNewItemObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });

      const requestToRequesterPayload = {
        data: {
          relationship_type: 'request_to_requester',
          source: newRequestObjectRecord.id,
          target: newRequesterObjectRecord.id
        }
      };

      const createRequestToRequesterRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequesterPayload });

      const requesterToRequestPayload = {
        data: {
          relationship_type: 'requester_to_request',
          source: newRequesterObjectRecord.id,
          target: newRequestObjectRecord.id
        }
      };

      const createRequesterToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requesterToRequestPayload });

      const requestToItemPayload = {
        data: {
          relationship_type: 'request_to_item',
          source: newRequestObjectRecord.id,
          target: newItemObjectRecord.id
        }
      };

      const createRequestToItemRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToItemPayload });

      const itemToRequestPayload = {
        data: {
          relationship_type: 'item_to_request',
          source: newItemObjectRecord.id,
          target: newRequestObjectRecord.id
        }
      };

      const createItemToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: itemToRequestPayload });

      const requesterToItemPayload = {
        data: {
          relationship_type: 'requester_to_item',
          source: newRequesterObjectRecord.id,
          target: newItemObjectRecord.id
        }
      };

      const createRequesterToItemRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requesterToItemPayload });

      const itemToRequesterPayload = {
        data: {
          relationship_type: 'item_to_requester',
          source: newItemObjectRecord.id,
          target: newRequesterObjectRecord.id
        }
      };

      const createItemToRequesterRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: itemToRequesterPayload });

      const requestToApprovalPayload = {
        data: {
          relationship_type: 'request_to_approval',
          source: newRequestObjectRecord.id,
          target: newApprovalObjectRecord.id
        }
      };

      const createRequestToApprovalRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToApprovalPayload });

      const approvalToRequestPayload = {
        data: {
          relationship_type: 'approval_to_request',
          source: newApprovalObjectRecord.id,
          target: newRequestObjectRecord.id
        }
      };

      const createApprovalToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: approvalToRequestPayload });

      const requestToRequestTypePayload = {
        data: {
          relationship_type: 'request_to_request_type',
          source: newRequestObjectRecord.id,
          target: requestType.id
        }
      };

      const createRequestToRequestTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToRequestTypePayload });

      const requestTypeToRequestPayload = {
        data: {
          relationship_type: 'request_type_to_request',
          source: requestType.id,
          target: newRequestObjectRecord.id
        }
      };

      const createRequestTypeToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestTypeToRequestPayload });

      await Promise.all([createRequestToRequesterRelationshipRecordPromise, createRequesterToRequestRelationshipRecordPromise, createRequestToApprovalRelationshipRecordPromise, createApprovalToRequestRelationshipRecordPromise, createRequestToRequestTypeRelationshipRecordPromise, createRequestTypeToRequestRelationshipRecordPromise, createRequestToItemRelationshipRecordPromise, createItemToRequestRelationshipRecordPromise, createRequesterToItemRelationshipRecordPromise, createItemToRequesterRelationshipRecordPromise]);

      const relatedAgentsToRequestType = await Promise.resolve(listRelatedAgentsToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });

      let approversList = [];
      relatedAgentsToRequestType.map(({ attributes: { email }}) => {
        approversList.push(email);
      });

      const internalNote = {
        ticket: {
          comment: { 
            body: `An approval request has been generated for this ticket. Please reload the Approvals app. \n\nWaiting on the following approvers\' action: \n - ${approversList.join('\n - ')}`,
            html_body: `An approval request has been generated on this ticket. Please reload the <strong>Approvals</strong> app.<br><br>Waiting on the following approvers\' action: <br> <ul><li> ${approversList.join('</li><li>')} </li></ul>`, 
            public: false
          }
        }
      };

      const settings = {
        headers: {
          'Content-Type': 'application/json'
        },
        url: `/api/v2/tickets/${ticket.id}.json`,
        method: 'PUT',
        data: JSON.stringify(internalNote)
      }

      await client.request(settings);
    }
  }

  const relatedItemsToRequesterObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: newRequesterObjectRecord.id, relationship_type: 'requester_to_item' }).then(({ data }) => { return data }, (error) => { return error });

  $('.config table.ticket-related-requests, .config table.user-related-requests').append('<tbody></tbody>');
  await generalFunctions.refreshTableRows({ itemList: relatedItemsToRequesterObjectRecords, ticketId: ticket.id });
  generalFunctions.registerGeneralEventsHandlers();
  generalFunctions.hideMainSpinner();
}

init();