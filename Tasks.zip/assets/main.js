let client;

const elementTemplates = {
  select: '<select class="uk-select" value=""><option>New</option><option>Completed</option>\
  <option>Pending</option></select>',
  selectTaskType: '<select class="uk-select task-type" value=""><option>Fullfillment</option><option>Implement</option>\
  <option>Review</option></select>'
};

const generalFunctions = {
  showMainSpinner: () => {
    $(window).scrollTop(0);
    $('.config').scrollLeft(0);
    $('#settings-loader').removeClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 0.05
    });
  },
  
  hideMainSpinner: () => {
    $('#settings-loader').addClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 1
    });
  },

  generateAlertMessage: ({ type, msg }) => {
    generalFunctions.removeAlertMessages();
    const alert = `<div class="uk-alert-${type}" uk-alert>\
    <a class="uk-alert-close" uk-close></a>\
    <p>${msg}</p></div>`;

    $('body').prepend(alert);
  },

  removeAlertMessages: () => {
    $('div[uk-alert]').remove();
  },

  getRowInputValue: (row) => {    
    let rowValues = {
      task_id: Number(row.find('input.task-number').val()),
      status: row.find('input.task-status').val(),
      description: row.find('input.task-description').val(),
    };

    return rowValues;
  },

  registerGeneralEventsHandlers: () => {
    $('.buttons-container .save').on('click', async () => {
      generalFunctions.showMainSpinner();

      const taskId = $('.config table tbody tr').attr('data-task-id');
      const rowValues = generalFunctions.getRowInputValue($('.config table tbody tr'));
      const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });

      const taskPayload = {
        data: {
          attributes: {
            task_id: rowValues['task_id'],
            status: rowValues['status'],
            fulfiller: {
              id: currentUser.id,
              name: currentUser.name,
              email: currentUser.email
            },
          }
        }
      };

      const updatedTaskObjectRecord = await sunshineApi.updateObjectRecord({ id: taskId, payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });
      const relatedRequestToTaskTypeObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: taskId, relationship_type: 'task_to_request' }).then(({ data }) => { return data }, (err) => { return err });

      if(updatedTaskObjectRecord.attributes.status.toLowerCase() === 'completed') {
          
        let internalNoteForCurrentTicket = {
          ticket: {
            status: 'solved',
            comment: { 
              body: `${rowValues.description} task has been completed. Please see ticket #${relatedRequestToTaskTypeObjectRecords[0]['external_id']} for more details.`,
              html_body: `${rowValues.description} task has been completed. Please see ticket <a href="/agent/tickets/${relatedRequestToTaskTypeObjectRecords[0]['external_id']}">#${relatedRequestToTaskTypeObjectRecords[0]['external_id']}</a> for more details.`,
              public: false
            }
          }
        };

        const currentTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: `/api/v2/tickets/${updatedTaskObjectRecord['external_id']}.json`,
          method: 'PUT',
          data: JSON.stringify(internalNoteForCurrentTicket)
        }
  
        const updatedCurrentTicket = await client.request(currentTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });
        console.log(updatedCurrentTicket);

        if(updatedCurrentTicket.status === 422) {
          generalFunctions.removeAlertMessages();
          generalFunctions.generateAlertMessage({ type: 'danger', msg: `${updatedCurrentTicket.responseJSON.details.base[0].description}. Update and submit ticket first before completing this task.` });
          client.invoke('resize', { width: '100%', height: '30vh' });
          generalFunctions.hideMainSpinner();
          return;
        } else {
          let internalNoteForSourceTicket = {
            ticket: {
              comment: { 
                body: `${rowValues.description} task set to completed.`,
                html_body: `${rowValues.description} task set to completed.`,
                public: false
              }
            }
          };
  
          const sourceTicketSettings = {
            headers: {
              'Content-Type': 'application/json'
            },
            url: `/api/v2/tickets/${relatedRequestToTaskTypeObjectRecords[0]['external_id']}.json`,
            method: 'PUT',
            data: JSON.stringify(internalNoteForSourceTicket)
          }
    
          await client.request(sourceTicketSettings);
        }
      }

      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully updated request' });
      client.invoke('resize', { width: '100%', height: '30vh' });
      generalFunctions.hideMainSpinner();
    });
  },

  refreshTableRows: async ({ task }) => {  
    console.log(task);
      
    $('.config table tbody').empty();
    
    let tableRow = `<tr data-task-id="${task.id}"><td><input class="uk-input uk-hidden task-number" type="text" value="${task['task_id']}" />${task['task_id']}</td>\
    <td><input class="uk-input uk-hidden fulfillers" type="text" value="${task.fulfillers.join(', ')}" /><span>${task.fulfillers.join(', ')}</span></td>\
    <td><input class="uk-input uk-hidden task-description" type="text" value="${task.description}" />${task.description}</td>\
    <td><input class="uk-input uk-hidden task-status" type="text" value="${task.status}" />${elementTemplates.select}</td></tr>`;

    $('.config table tbody').append(tableRow);
    $(`.config table tbody tr[data-task-id="${task.id}"] select`).val(task.status);
    
    const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });

    if(!task.fulfillers.includes(currentUser.email)) {
      $(`.config table tbody tr[data-task-id="${task.id}"] select`).attr('disabled', true);
    }

    $(`.config table tbody tr[data-task-id="${task.id}"] select`).on('change', () => {
      const selectVal = event.target.value;
      $(event.currentTarget).siblings('input').val(selectVal);
    });
  }
}

const init = async () => {
  // General
  const jqueryInit = await Promise.resolve($());
  generalFunctions.showMainSpinner();
  client = await Promise.resolve(ZAFClient.init());
  const appUpdateHeight = await Promise.resolve(client.invoke('resize', { width: '100%', height: '20vh' }));
  const appRegistered = await Promise.resolve(client.on('app.registered'));

  const getTicketPromise = client.get('ticket');
  const getCurrentUserPromise = client.get('currentUser');

  const ticket = await Promise.resolve(getTicketPromise).then(({ ticket }) => { return ticket }, (err) => { return err });
  const taskObjectRecord = await sunshineApi.showObjectRecordByExternalId({ object_type: 'task', external_id: ticket.id }).then(({ data }) => { return data }, (err) => { return err });
  
  if(taskObjectRecord.status === 404) {
    $('.config').addClass('uk-hidden');
    generalFunctions.generateAlertMessage({ type: '', msg: 'Found 0 tasks for this user' });
    client.invoke('resize', { width: '100%', height: '10vh' });
    generalFunctions.hideMainSpinner();
    return;
  }

  const relatedTaskTypeToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: taskObjectRecord[0].id, relationship_type: 'task_to_task_type' }).then(({ data }) => { return data }, (err) => { return err });
  
  const relatedAgentToTaskTypeObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: relatedTaskTypeToRequestObjectRecords[0].id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });

  let task = {
    id: taskObjectRecord[0].id,
    task_id: taskObjectRecord[0].attributes['task_id'],
    status: taskObjectRecord[0].attributes.status,
    fulfillers: [],
    description: relatedTaskTypeToRequestObjectRecords[0].attributes.name,
  };

  relatedAgentToTaskTypeObjectRecords.map(({ attributes: { email }}) => {
    task.fulfillers.push(email);
  });

  $('.config table').append('<tbody></tbody>');
  await generalFunctions.refreshTableRows({ task });
  generalFunctions.registerGeneralEventsHandlers();
  generalFunctions.hideMainSpinner();
}

init();