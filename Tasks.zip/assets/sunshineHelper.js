const sunshineApi = {
  sendApiRequest: ({ headers, url, method, data }) => {
    const settings = {
      headers,
      url,
      type: method,
      dataType: 'json',
      data: JSON.stringify(data)
    };
    const promise = new Promise((resolve, reject) => {
      client.request(settings).then((data) => {
        resolve(data);
      }, (err) => {
        reject(err);
      });
    });
    return promise;
  },

  listObjectTypes: () => {
    const config = {
      url: '/api/sunshine/objects/types',
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  showObjectType: ({ key }) => {
    const config = {
      url: `/api/sunshine/objects/types/${key}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },
  
  createObjectType: ({ payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/sunshine/objects/types',
      method: 'POST',
      data: payload
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  updateObjectType: ({ key, payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/merge-patch+json'
      },
      url: `/api/sunshine/objects/types/${key}`,
      method: 'PATCH',
      data: payload
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  deleteObjectType: ({ key }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: `/api/sunshine/objects/types/${key}`,
      method: 'DELETE'
    };
  
    return sunshineApi.sendApiRequest(config);
  },
  
  listObjectRecordsByType: ({ object_type, params }) => {
    const config = {
      url: `/api/sunshine/objects/records?type=${object_type}&${params}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  listObjectRecordsById: ({ ids }) => {
    const config = {
      url: `/api/sunshine/objects/records?ids=${ids}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  listRelatedObjectRecords: ({ id, relationship_type, params }) => {
    const config = {
      url: `/api/sunshine/objects/records/${id}/related/${relationship_type}?${params}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  showObjectRecord: ({ id }) => {
    const config = {
      url: `/api/sunshine/objects/records/${id}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  showObjectRecordByExternalId: ({ object_type, external_id }) => {
    const config = {
      url: `/api/sunshine/objects/records?type=${object_type}&external_id=${external_id}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  showObjectRecordByExternalIds: ({ object_type, external_id }) => {
    const config = {
      url: `/api/sunshine/objects/records?type=${object_type}&external_ids=${external_id}`,
      method: 'GET'
    };
  
    return sunshineApi.sendApiRequest(config);
  },
  
  createObjectRecord: ({ payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/sunshine/objects/records',
      method: 'POST',
      data: payload
    };
  
    return sunshineApi.sendApiRequest(config);
  },
  
  updateObjectRecord: ({ id, payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/merge-patch+json'
      },
      url: `/api/sunshine/objects/records/${id}`,
      method: 'PATCH',
      data: payload
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  setObjectRecordByExternalId: ({ payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/merge-patch+json'
      },
      url: '/api/sunshine/objects/records',
      method: 'PATCH',
      data: payload
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  deleteObjectRecord: ({ id }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: `/api/sunshine/objects/records/${id}`,
      method: 'DELETE'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  deleteObjectRecordByExternalId: ({ external_id, object_type }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: `/api/sunshine/objects/records?external_id=${external_id}&type=${object_type}`,
      method: 'DELETE'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  listRelationshipTypes: () => {
    const config = {
      url: '/api/sunshine/relationships/types',
      method: 'GET'
    };

    return sunshineApi.sendApiRequest(config);
  },

  showRelationshipType: ({ key }) => {
    const config = {
      url: `/api/sunshine/relationships/types/${key}`,
      method: 'GET'
    };

    return sunshineApi.sendApiRequest(config);
  },

  createRelationshipType: ({ payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/sunshine/relationships/types',
      method: 'POST',
      data: payload
    };

    return sunshineApi.sendApiRequest(config);
  },

  deleteRelationshipType: ({ key }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: `/api/sunshine/relationships/types/${key}`,
      method: 'DELETE'
    };
  
    return sunshineApi.sendApiRequest(config);
  },

  listRelationshipRecordsByObjectRecord: ({ id, relationship_type, params }) => {
    const config = {
      url: `/api/sunshine/objects/records/${id}/relationships/${relationship_type}?${params}`,
      method: 'GET'
    };

    return sunshineApi.sendApiRequest(config);
  },

  listRelationshipRecordsByType: ({ relationship_type, params }) => {
    const config = {
      url: `/api/sunshine/relationships/records?type=${relationship_type}&${params}`,
      method: 'GET'
    };

    return sunshineApi.sendApiRequest(config);
  },

  showRelationshipRecordById: ({ id }) => {
    const config = {
      url: `/api/sunshine/relationships/records/${id}`,
      method: 'GET'
    };

    return sunshineApi.sendApiRequest(config);
  },

  createRelationshipRecord: ({ payload }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/sunshine/relationships/records',
      method: 'POST',
      data: payload
    };

    return sunshineApi.sendApiRequest(config);
  },

  deleteRelationshipRecord: ({ id }) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: `/api/sunshine/relationships/records/${id}`,
      method: 'DELETE'
    };
  
    return sunshineApi.sendApiRequest(config);
  }
}