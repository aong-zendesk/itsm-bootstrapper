let client;

const elementTemplates = {
  checkBox: '<input class="uk-checkbox" type="checkbox">',
};

const generalFunctions = {
  showMainSpinner: () => {
    $(window).scrollTop(0);
    $('.config').scrollLeft(0);
    $('#settings-loader').removeClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 0.05
    });
  },
  
  hideMainSpinner: () => {
    $('#settings-loader').addClass('uk-hidden');
    $('.config, .buttons-container').css({
      opacity: 1
    });
  },

  generateAlertMessage: ({ type, msg }) => {
    generalFunctions.removeAlertMessages();
    const alert = `<div class="uk-alert-${type}" uk-alert>\
    <a class="uk-alert-close" uk-close></a>\
    <p>${msg}</p></div>`;

    $('body').prepend(alert);
  },

  removeAlertMessages: () => {
    $('div[uk-alert]').remove();
  },

  registerGeneralEventsHandlers: () => {
    $('.buttons-container .approve').on('click', async () => {
      generalFunctions.showMainSpinner();
      const ticket = await client.get('ticket').then(({ ticket }) => { return ticket }, (err) => { return err });
      const requestObjectRecord = await sunshineApi.showObjectRecordByExternalId({ object_type: 'request', external_id: ticket.id }).then(({ data }) => { return data }, (err) => { return err });
      const relatedApprovalsToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_approval' }).then(({ data }) => { return data }, (err) => { return err });
      
      const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });
      
      const approvalPayload = {
        data: {
          type: 'approval',
          attributes: {
            approver: {
              id: currentUser.id,
              name: currentUser.name,
              email: currentUser.email
            },
            status: 'Approved',
            rejection_comment: ''
          }
        }
      };

      const updatedApprovalObjectRecordPromise = sunshineApi.updateObjectRecord({ id:relatedApprovalsToRequestObjectRecords[0].id, payload: approvalPayload });
      
      const relatedRequestTypeToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_request_type' }).then(({ data }) => { return data }, (err) => { return err });

      const listRelatedAgentToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: relatedRequestTypeToRequestObjectRecords[0].id, relationship_type: 'request_type_to_agent' });
      const listRelatedItemToRequestPromise = sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_item' });

      const relatedAgentToRequestTypeObjectRecords = await Promise.resolve(listRelatedAgentToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });
      const relatedItemToRequestObjectRecords = await Promise.resolve(listRelatedItemToRequestPromise).then(({ data }) => { return data }, (err) => { return err });
      
      const approvers = relatedAgentToRequestTypeObjectRecords;
      const approval = await Promise.resolve(updatedApprovalObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      const item = relatedItemToRequestObjectRecords[0];
      const requestType = relatedRequestTypeToRequestObjectRecords[0];

      const taskObjectRecords = await sunshineApi.listObjectRecordsByType({ object_type: 'task' }).then(({ data }) => { return data }, (err) => { return err });
      const taskTypeObjectRecords = await sunshineApi.listObjectRecordsByType({ object_type: 'task_type' }).then(({ data }) => { return data }, (err) => { return err });

      let taskPayload = {
        data: {
          type: 'task',
          attributes: {
            task_id: taskObjectRecords.length + 1001,
            status: 'New',
            fulfiller: {}
          }
        }
      };
  
      if(requestType.attributes.name.includes('Change')) {
        const implementTaskType = taskTypeObjectRecords.find(({ attributes: { name } }) => {
          return name === 'Implement'
        });

        const implementTaskTypeToAgentObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: implementTaskType.id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });
        let implementTaskFulfillerList = [];
        
        implementTaskTypeToAgentObjectRecords.map(({ attributes: { email }}) => {
          implementTaskFulfillerList.push(email);
        });

        let internalNoteForImplementTicketPayload = {
          ticket: {
            subject: 'Implement task',
            comment: { 
              html_body: `This is an Implement task for ticket <a href="/agent/tickets/${ticket.id}">#${ticket.id}</a>. Please see Task app for more details.`, 
              body: `This is an Implement task for ticket ${ticket.id}`,
              public: false
            }
          }
        };

        const implementTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: '/api/v2/tickets',
          method: 'POST',
          data: JSON.stringify(internalNoteForImplementTicketPayload)
        }
  
        const implementTicket = await client.request(implementTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });

        let internalNoteForCurrentTicketPayload = {
          ticket: {
            comment: { 
              body: `An Implement task has been generated for this request. Please see ticket #${implementTicket.id}. \n\nWaiting on the following fulfillers\' action: \n - ${implementTaskFulfillerList.join('\n - ')}`,
              html_body: `An Implement task has been generated for this request. Please see ticket <a href="/agent/tickets/${implementTicket.id}">#${implementTicket.id}</a>.<br><br>Waiting on the following fulfillers\' action: <br> <ul><li> ${implementTaskFulfillerList.join('</li><li>')} </li></ul>`,
              public: false
            }
          }
        };
          
        let currentTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: `/api/v2/tickets/${ticket.id}.json`,
          method: 'PUT',
          data: JSON.stringify(internalNoteForCurrentTicketPayload)
        }
    
        await client.request(currentTicketSettings);

        taskPayload.data['external_id'] = implementTicket.id;

        const implementTaskObjectRecord = await sunshineApi.createObjectRecord({ payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });
        
        const implementTaskToRequestPayload = {
          data: {
            relationship_type: 'task_to_request',
            source: implementTaskObjectRecord.id,
            target: requestObjectRecord[0].id
          }
        };

        const createImplementTaskToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: implementTaskToRequestPayload });

        const requestToImplementTaskPayload = {
          data: {
            relationship_type: 'request_to_task',
            source: requestObjectRecord[0].id,
            target: implementTaskObjectRecord.id
          }
        };

        const createRequestToImplementTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToImplementTaskPayload });
          
        const implementTaskToTaskTypePayload = {
          data: {
            relationship_type: 'task_to_task_type',
            source: implementTaskObjectRecord.id,
            target: implementTaskType.id
          }
        };

        const createImplementTaskToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: implementTaskToTaskTypePayload });

        const taskTypeToImplementTaskPayload = {
          data: {
            relationship_type: 'task_type_to_task',
            source: implementTaskType.id,
            target: implementTaskObjectRecord.id
          }
        };

        const createTaskTypeToImplementTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToImplementTaskPayload });

        const reviewTaskType = taskTypeObjectRecords.find(({ attributes: { name } }) => {
          return name === 'Review'
        });

        const reviewTaskTypeToAgentObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: reviewTaskType.id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });
        let reviewTaskFulfillerList = [];
        
        reviewTaskTypeToAgentObjectRecords.map(({ attributes: { email }}) => {
          reviewTaskFulfillerList.push(email);
        });

        let internalNoteForReviewTicketPayload = {
          ticket: {
            subject: 'Review task',
            comment: { 
              html_body: `This is a Review task for ticket <a href="/agent/tickets/${ticket.id}">#${ticket.id}</a>. Please see Task app for more details.`, 
              body: `This is a Review task for ticket ${ticket.id}`,
              public: false
            }
          }
        };

        const reviewTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: '/api/v2/tickets',
          method: 'POST',
          data: JSON.stringify(internalNoteForReviewTicketPayload)
        }
  
        const reviewTicket = await client.request(reviewTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });

        internalNoteForCurrentTicketPayload = {
          ticket: {
            comment: { 
              body: `A Review task has been generated for this request. Please see ticket #${reviewTicket.id}. \n\nWaiting on the following fulfillers\' action: \n - ${reviewTaskFulfillerList.join('\n - ')}`,
              html_body: `A Review task has been generated for this request. Please see ticket <a href="/agent/tickets/${reviewTicket.id}">#${reviewTicket.id}</a>.<br><br>Waiting on the following fulfillers\' action: <br> <ul><li> ${reviewTaskFulfillerList.join('</li><li>')} </li></ul>`,
              public: false
            }
          }
        };
          
        currentTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: `/api/v2/tickets/${ticket.id}.json`,
          method: 'PUT',
          data: JSON.stringify(internalNoteForCurrentTicketPayload)
        }
    
        await client.request(currentTicketSettings);
        
        taskPayload.data['external_id'] = reviewTicket.id;
        taskPayload.data.attributes['task_id'] = taskPayload.data.attributes['task_id'] + 1;
        const reviewTaskObjectRecord = await sunshineApi.createObjectRecord({ payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });

        const reviewTaskToRequestPayload = {
          data: {
            relationship_type: 'task_to_request',
            source: reviewTaskObjectRecord.id,
            target: requestObjectRecord[0].id
          }
        };

        const createReviewTaskToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: reviewTaskToRequestPayload });

        const requestToReviewTaskPayload = {
          data: {
            relationship_type: 'request_to_task',
            source: requestObjectRecord[0].id,
            target: reviewTaskObjectRecord.id
          }
        };

        const createRequestToReviewTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToReviewTaskPayload });

        const reviewTaskToTaskTypePayload = {
          data: {
            relationship_type: 'task_to_task_type',
            source: reviewTaskObjectRecord.id,
            target: reviewTaskType.id
          }
        };

        const createReviewTaskToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: reviewTaskToTaskTypePayload });

        const taskTypeToReviewTaskPayload = {
          data: {
            relationship_type: 'task_type_to_task',
            source: reviewTaskType.id,
            target: reviewTaskObjectRecord.id
          }
        };

        const createTaskTypeToReviewTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToReviewTaskPayload });

        await Promise.all([
          createImplementTaskToRequestRelationshipRecordPromise, 
          createRequestToImplementTaskRelationshipRecordPromise, 
          createImplementTaskToTaskTypeRelationshipRecordPromise, 
          createTaskTypeToImplementTaskRelationshipRecordPromise, 
          createReviewTaskToRequestRelationshipRecordPromise, 
          createRequestToReviewTaskRelationshipRecordPromise, 
          createReviewTaskToTaskTypeRelationshipRecordPromise, 
          createTaskTypeToReviewTaskRelationshipRecordPromise
        ]);
      } else {
        const fulfillmentTaskType = taskTypeObjectRecords.find(({ attributes: { name } }) => {
          return name === 'Fulfillment'
        });

        const fulfillmentTaskTypeToAgentObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: fulfillmentTaskType.id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (err) => { return err });
        let fulfillmentTaskFulfillerList = [];
        
        fulfillmentTaskTypeToAgentObjectRecords.map(({ attributes: { email }}) => {
          fulfillmentTaskFulfillerList.push(email);
        });

        let internalNoteForFulfillmentTicketPayload = {
          ticket: {
            subject: 'Fulfillment task',
            comment: { 
              html_body: `This is a fulfillment task for ticket <a href="/agent/tickets/${ticket.id}">#${ticket.id}</a>. Please see Task app for more details.`, 
              body: `This is a fulfillment task for ticket ${ticket.id}`,
              public: false
            }
          }
        };

        const fulfillmentTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: '/api/v2/tickets',
          method: 'POST',
          data: JSON.stringify(internalNoteForFulfillmentTicketPayload)
        }
  
        const fulfillmentTicket = await client.request(fulfillmentTicketSettings).then(({ ticket }) => { return ticket }, (err) => { return err });

        let internalNoteForCurrentTicketPayload = {
          ticket: {
            comment: { 
              body: `A Fulfillment task has been generated for this request. Please see ticket #${fulfillmentTicket.id}. \n\nWaiting on the following fulfillers\' action: \n - ${fulfillmentTaskFulfillerList.join('\n - ')}`,
              html_body: `A Fulfillment task has been generated for this request. Please see ticket <a href="/agent/tickets/${fulfillmentTicket.id}">#${fulfillmentTicket.id}</a>.<br><br>Waiting on the following fulfillers\' action: <br> <ul><li> ${fulfillmentTaskFulfillerList.join('</li><li>')} </li></ul>`,
              public: false
            }
          }
        };
          
        const currentTicketSettings = {
          headers: {
            'Content-Type': 'application/json'
          },
          url: `/api/v2/tickets/${ticket.id}.json`,
          method: 'PUT',
          data: JSON.stringify(internalNoteForCurrentTicketPayload)
        }
    
        await client.request(currentTicketSettings);
        taskPayload.data['external_id'] = fulfillmentTicket.id;
        
        console.log('taskPayload:');
        console.log(taskPayload);

        const fulfillmentTaskObjectRecord = await sunshineApi.createObjectRecord({ payload: taskPayload }).then(({ data }) => { return data }, (err) => { return err });
        
        const fulfillmentTaskToRequestPayload = {
          data: {
            relationship_type: 'task_to_request',
            source: fulfillmentTaskObjectRecord.id,
            target: requestObjectRecord[0].id
          }
        };

        const createFulfillmentTaskToRequestRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToRequestPayload });

        const requestToFulfillmentTaskPayload = {
          data: {
            relationship_type: 'request_to_task',
            source: requestObjectRecord[0].id,
            target: fulfillmentTaskObjectRecord.id
          }
        };

        const createRequestToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestToFulfillmentTaskPayload });

        const fulfillmentTaskToTaskTypePayload = {
          data: {
            relationship_type: 'task_to_task_type',
            source: fulfillmentTaskObjectRecord.id,
            target: fulfillmentTaskType.id
          }
        };

        const createFulfillmentTaskToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: fulfillmentTaskToTaskTypePayload });

        const taskTypeToFulfillmentTaskPayload = {
          data: {
            relationship_type: 'task_type_to_task',
            source: fulfillmentTaskType.id,
            target: fulfillmentTaskObjectRecord.id
          }
        };

        const createTaskTypeToFulfillmentTaskRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToFulfillmentTaskPayload });

        await Promise.all([
          createFulfillmentTaskToRequestRelationshipRecordPromise, 
          createRequestToFulfillmentTaskRelationshipRecordPromise, 
          createFulfillmentTaskToTaskTypeRelationshipRecordPromise, 
          createTaskTypeToFulfillmentTaskRelationshipRecordPromise
        ]);
      }

      generalFunctions.refreshTableRows({ approval, approvers, item, requestType });
      generalFunctions.hideMainSpinner();
    });
    

    $('.buttons-container .reject').on('click', async () => {
      generalFunctions.showMainSpinner();
      const comment = $('.config .comment.uk-textarea').val();
      
      if(!comment) {
        generalFunctions.removeAlertMessages();
        generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You must leave a comment when rejecting a request' });
        client.invoke('resize', { width: '100%', height: '50vh' });
        generalFunctions.hideMainSpinner();
        return;
      }

      const ticket = await client.get('ticket').then(({ ticket }) => { return ticket }, (err) => { return err });
      const requestObjectRecord = await sunshineApi.showObjectRecordByExternalId({ object_type: 'request', external_id: ticket.id }).then(({ data }) => { return data }, (err) => { return err });
      const relatedApprovalsToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_approval' }).then(({ data }) => { return data }, (err) => { return err });
      
      const currentUser = await client.get('currentUser').then(({ currentUser }) => { return currentUser }, (err) => { return err });
      
      const approvalPayload = {
        data: {
          type: 'approval',
          attributes: {
            approver: {
              id: currentUser.id,
              name: currentUser.name,
              email: currentUser.email
            },
            status: 'Rejected',
            rejection_comment: comment
          }
        }
      };

      const updatedApprovalObjectRecordPromise = sunshineApi.updateObjectRecord({ id:relatedApprovalsToRequestObjectRecords[0].id, payload: approvalPayload });
      const relatedRequestTypeToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_request_type' }).then(({ data }) => { return data }, (err) => { return err });

      const listRelatedAgentToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: relatedRequestTypeToRequestObjectRecords[0].id, relationship_type: 'request_type_to_agent' });
      const listRelatedItemToRequestPromise = sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_item' });

      const relatedAgentToRequestTypeObjectRecords = await Promise.resolve(listRelatedAgentToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });
      const relatedItemToRequestObjectRecords = await Promise.resolve(listRelatedItemToRequestPromise).then(({ data }) => { return data }, (err) => { return err });
      
      const approvers = relatedAgentToRequestTypeObjectRecords;
      const approval = await Promise.resolve(updatedApprovalObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
      const item = relatedItemToRequestObjectRecords[0];
      const requestType = relatedRequestTypeToRequestObjectRecords[0];

      let internalNoteForCurrentTicketPayload = {
        ticket: {
          comment: { 
            body: `An Approval request on this ticket has been rejected. Reason: ${comment}`,
            html_body: `An Approval request on this ticket has been rejected. <br />Reason: ${comment}`,
            public: false
          }
        }
      };
        
      const currentTicketSettings = {
        headers: {
          'Content-Type': 'application/json'
        },
        url: `/api/v2/tickets/${ticket.id}.json`,
        method: 'PUT',
        data: JSON.stringify(internalNoteForCurrentTicketPayload)
      }
  
      await client.request(currentTicketSettings);

      generalFunctions.refreshTableRows({ approval, approvers, item, requestType });
      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully rejected approval request' });
      generalFunctions.hideMainSpinner();
    });
  },

  refreshTableRows: async ({ approval, approvers, item, requestType }) => {
    $('.config table tbody').empty();

    if($.isEmptyObject(approval)) {
      $('.config').addClass('uk-hidden');
      generalFunctions.generateAlertMessage({ type: '', msg: 'Found 0 requests for this user' });
      client.invoke('resize', { width: '100%', height: '10vh' });
      return;
    }

    const statusWithComment = approval.attributes.status.toLowerCase() !== 'rejected' ? approval.attributes.status : `Rejected: ${approval.attributes.rejection_comment}`;

    const approverList = [];
    
    approvers.map(({ attributes: { email } }) => {
      approverList.push(email);
    });
 
    let tableRow = `<tr data-approval-id="${approval.id}" data-request-type="${requestType.attributes.name}">\
    <td>${statusWithComment}</td><td>${approverList.join(', ')}</td>
    <td><span>${item.attributes.type}: </span><span>${item.attributes.model}</span></td></tr>`;

    console.log(approval.attributes.status.toLowerCase());

    if(approval.attributes.status.toLowerCase() !== 'pending') {
      $('button.approve, button.reject').addClass('disabled-btn');
      $('textarea.reason').attr('disabled', true);
    }

    $('.config table tbody').append(tableRow);
  }
}

const init = async () => {
  // General
  const jqueryInit = await Promise.resolve($());
  generalFunctions.showMainSpinner();
  client = await Promise.resolve(ZAFClient.init());
  const appUpdateHeight = await Promise.resolve(client.invoke('resize', { width: '100%', height: '35vh' }));
  const appRegistered = await Promise.resolve(client.on('app.registered'));

  const getTicketPromise = client.get('ticket');
  const getCurrentUserPromise = client.get('currentUser');

  const ticket = await Promise.resolve(getTicketPromise).then(({ ticket }) => { return ticket }, (err) => { return err });
  const showRequestObjectRecordPromise = sunshineApi.showObjectRecordByExternalId({ object_type: 'request', external_id: ticket.id });

  const currentUser = await Promise.resolve(getCurrentUserPromise).then(({ currentUser }) => { return currentUser }, (err) => { return err });
  const agentPayload = {
    data: {
      type: 'agent', 
      external_id: currentUser.id, 
      attributes: {
        name: currentUser.name, 
        email: currentUser.email
      }
    }
  };
  
  const setAgentObjectRecordPromise = sunshineApi.setObjectRecordByExternalId({ payload: agentPayload });

  const requestObjectRecord = await Promise.resolve(showRequestObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });
  const agentObjectRecord = await Promise.resolve(setAgentObjectRecordPromise).then(({ data }) => { return data }, (err) => { return err });

  let approval = {};
  let approvers = [];
  let item = {};
  let requestType = {};

  if(requestObjectRecord.length > 0) {
    const relatedApprovalsToRequestObjectRecords = await sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_approval' }).then(({ data }) => { return data }, (err) => { return err });

    if(relatedApprovalsToRequestObjectRecords.length > 0) {
      const listRelatedRequestTypeToRequestPromise = sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_request_type' });
      const listRelatedRequestTypeToAgentPromise = sunshineApi.listRelatedObjectRecords({ id: agentObjectRecord.id, relationship_type: 'agent_to_request_type' });

      const relatedRequestTypeToRequestObjectRecords = await Promise.resolve(listRelatedRequestTypeToRequestPromise).then(({ data }) => { return data }, (err) => { return err });

      const relatedRequestTypeToAgentObjectRecords = await Promise.resolve(listRelatedRequestTypeToAgentPromise).then(({ data }) => { return data }, (err) => { return err });

      requestType = relatedRequestTypeToAgentObjectRecords.find(({ id }) => {
        return id === relatedRequestTypeToRequestObjectRecords[0].id
      });

      let isApprover = !requestType ? false : true;

      if(isApprover) {        
        const listRelatedAgentToRequestTypePromise = sunshineApi.listRelatedObjectRecords({ id: requestType.id, relationship_type: 'request_type_to_agent' });
        const listRelatedItemToRequestPromise = sunshineApi.listRelatedObjectRecords({ id: requestObjectRecord[0].id, relationship_type: 'request_to_item' });

        const relatedAgentToRequestTypeObjectRecords = await Promise.resolve(listRelatedAgentToRequestTypePromise).then(({ data }) => { return data }, (err) => { return err });
        const relatedItemToRequestObjectRecords = await Promise.resolve(listRelatedItemToRequestPromise).then(({ data }) => { return data }, (err) => { return err });
        
        approvers = relatedAgentToRequestTypeObjectRecords;
        approval = relatedApprovalsToRequestObjectRecords[0];
        item = relatedItemToRequestObjectRecords[0];
      }
    }
  }
    
  $('.config table').append('<tbody></tbody>');
  generalFunctions.refreshTableRows({ approval, approvers, item, requestType });
  generalFunctions.registerGeneralEventsHandlers();
  generalFunctions.hideMainSpinner();
}

init();