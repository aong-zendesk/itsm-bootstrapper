let client;

const htmlTemplates = {
  editButton: '<a class="action-btn edit-record" href="javascript:void(0)" uk-icon="icon: file-edit"></a>',
  updateButton: '<a class="action-btn update-record uk-hidden" href="javascript:void(0)" uk-icon="icon: check"></a>',
  cancelButton: '<a class="action-btn cancel-record uk-hidden" href="javascript:void(0)" uk-icon="icon: ban"></a>',
  spinner: '<div class="spinner-load uk-hidden" uk-spinner></div>',
  ticketFormSelect: '<select class="uk-select ticket-form" value="" disabled><option>-</option></select>',
  ticketFieldSelect: '<select class="uk-select ticket-field" value="" disabled><option>-</option></select>'
};

const generalFunctions = {
  showButtonSpinner: (parent) => {
    $(parent).find('.spinner-load').removeClass('uk-hidden');
  },

  hideButtonSpinner: (parent) => {
    $(parent).find('.spinner-load').addClass('uk-hidden');
  },

  showMainSpinner: () => {
    $('#settings-loader').removeClass('uk-hidden');
    $('.config.uk-container').css({
      opacity: 0.05
    });
  },
  
  hideMainSpinner: () => {
    $('#settings-loader').addClass('uk-hidden');
    $('.config.uk-container').css({
      opacity: 1
    });
  },

  generateAlertMessage: ({ type, msg }) => {
    generalFunctions.removeAlertMessages();
    const alert = `<div class="uk-alert-${type}" uk-alert>\
    <a class="uk-alert-close" uk-close></a>\
    <p>${msg}</p></div>`;

    $('.config').prepend(alert);
  },

  removeAlertMessages: () => {
    $('div[uk-alert]').remove();
  },

  getRequestTypeRowValues: (row) => {
    const rowData = {
      requestTypeName: row.find('span.request-type-name').html(),
      requestTypeId: row.attr('data-request-type-id'),
      ticketFormId: row.find('select.ticket-form').val(),
      ticketFieldId: row.find('select.ticket-field').val(),
      approversList: row.find('input.approvers-list').val().replace(/\ /g, '').split(',')
    }
    return rowData;
  },

  getTaskTypeRowValues: (row) => {
    const rowData = {
      taskTypeName: row.find('span.task-type-name').html(),
      taskTypeId: row.attr('data-task-type-id'),
      fulfillersList: row.find('input.fulfillers-list').val().replace(/\ /g, '').split(',')
    }
    return rowData;
  },

  enableRowEditor: (callerBtn) => {
    callerBtn.parent().siblings('td:has("input, select")').children().each((index, elem) => {
      if($(elem).is('input')) {
        $(elem).removeClass('uk-hidden');
      } else if($(elem).is('select')) {
        $(elem).removeAttr('disabled');
      } else {
        $(elem).addClass('uk-hidden');
      }
    });
    callerBtn.siblings('a').removeClass('uk-hidden');
    callerBtn.addClass('uk-hidden');
  },

  disableRowEditor: (callerBtn) => {
    callerBtn.parent().siblings('td:has("input, select")').children().each((index, elem) => {
      if($(elem).is('input')) {
        $(elem).addClass('uk-hidden');
      } else if($(elem).is('select')) {
        $(elem).attr('disabled', true);
      } else {
        $(elem).removeClass('uk-hidden');
      }
    });

    callerBtn.siblings('a').addBack().addClass('uk-hidden');
    callerBtn.siblings('a.edit-record').removeClass('uk-hidden');
  },

  registerEventListeners: () => {
    $('a.edit-record').on('click', () => {
      $(event.currentTarget).parent().siblings('td:has(select)').each((index, elem) => {
        const previousVal = $(elem).find('select').val();
        $(elem).find('select').data('previous-value', previousVal);
      });

      $(event.currentTarget).parent().siblings('td:has(input)').each((index, elem) => {
        const previousVal = $(elem).find('input').val().replace(/\ /g, '').split(',');
        $(elem).find('input').data('previous-value', previousVal);
      });

      generalFunctions.enableRowEditor($(event.currentTarget));
    });

    $('a.cancel-record').on('click', () => {
      $(event.currentTarget).parent().siblings('td:has(select)').each((index, elem) => {
        const previousVal = $(elem).find('select').data('previous-value');
        $(elem).find('select').val(previousVal);
      });

      $(event.currentTarget).parent().siblings('td:has(input)').each((index, elem) => {
        const previousVal = $(elem).find('input').data('previous-value').join(', ');
        $(elem).find('input').val(previousVal);
      });

      generalFunctions.disableRowEditor($(event.currentTarget));
    });

    $('table.approvers select.ticket-form').on('change', async () => {
      const rowId = $(event.currentTarget).parents('tr').attr('data-request-type-id');
      const currentTicketFormId = Number($(event.currentTarget).val());

      const listTicketFormsPromise = generalFunctions.listTicketForms();
      const listTicketFieldsPromise = generalFunctions.listTicketFields();

      const ticketForms = await Promise.resolve(listTicketFormsPromise);
      const ticketFields = await Promise.resolve(listTicketFieldsPromise);

      generalFunctions.refreshTicketFieldSelect({ rowId, ticketForms, currentTicketFormId, ticketFields });      
    });

    $('table.approvers a.update-record').on('click', async () => {
      const clickedElem = $(event.currentTarget);
      generalFunctions.showButtonSpinner(clickedElem.parent());
      const rowValues = generalFunctions.getRequestTypeRowValues(clickedElem.parents('tr'));
      
      if(rowValues.ticketFormId === '-' || rowValues.ticketFieldId === '-') {
        generalFunctions.removeAlertMessages();
        generalFunctions.generateAlertMessage({ type: 'danger', msg: 'You must choose a ticket form and ticket field' });
        generalFunctions.hideButtonSpinner(clickedElem.parent());
        return;
      }
      
      const payload = {
        data: {
          attributes: {
            ticket_form_id: Number(rowValues.ticketFormId) || 0,
            ticket_field_id: Number(rowValues.ticketFieldId) || 0
          }
        }
      };

      const updateRequestTypePromise = sunshineApi.updateObjectRecord({ id: rowValues.requestTypeId, payload });
      const searchUsersPromise = sunshineApi.sendApiRequest({ url: '/api/v2/search.json?query=type:user%20role:agent%20role:admin', method: 'GET' });
      const listOldApproversPromise = sunshineApi.listRelatedObjectRecords({ id: rowValues.requestTypeId, relationship_type: 'request_type_to_agent' });

      await Promise.resolve(updateRequestTypePromise);
      const agents = await Promise.resolve(searchUsersPromise).then(({ results }) => { return results }, (err) => { return err });
      const oldApproversList = await Promise.resolve(listOldApproversPromise).then(({ data }) => { return data }, (err) => { return err });
      const newApproversList = rowValues.approversList;

      const createNewApproverRecordPromise = newApproversList.map(async (newApproverEmail) => {
        let agentEmail = oldApproversList.find(({ attributes: { email }}) => {
          return email === newApproverEmail
        });

        if(!agentEmail) {
          const agent = agents.find(({ email }) => {
            return email === newApproverEmail
          });

          if(!agent) {
            return;
          }

          const agentObjectRecordPayload = {
            data: {
              type: 'agent',
              external_id: agent.id,
              attributes: {
                name: agent.name,
                email: agent.email
              }
            }
          };
          
          const newAgentObjectRecord = await Promise.resolve(sunshineApi.setObjectRecordByExternalId({ payload: agentObjectRecordPayload })).then(({ data }) => { return data }, (err) => { return err });
          
          const requestTypeToAgentPayload = {
            data: {
              relationship_type: 'request_type_to_agent',
              source: rowValues.requestTypeId,
              target: newAgentObjectRecord.id
            }
          };

          const createRequestTypeToAgentRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: requestTypeToAgentPayload });

          const agentToRequestTypePayload = {
            data: {
              relationship_type: 'agent_to_request_type',
              source: newAgentObjectRecord.id,
              target: rowValues.requestTypeId
            }
          };

          const createAgentToRequestTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: agentToRequestTypePayload });

          await Promise.resolve(createRequestTypeToAgentRelationshipRecordPromise);
          await Promise.resolve(createAgentToRequestTypeRelationshipRecordPromise);
        }
      });  

      const deleteNonExistingApproverPromise = oldApproversList.map(async ({ id: agentRecordId, attributes: { email }}) => {
        let agentEmail = newApproversList.find((oldApproverEmail) => {
          return email === oldApproverEmail
        });

        if(!agentEmail) {
          const listRequestTypeToAgentRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByType({ relationship_type: 'request_type_to_agent' });
          const listAgentToRequestTypeRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByType({ relationship_type: 'agent_to_request_type' });

          const requestTypeToAgentRelationshipRecords = await Promise.resolve(listRequestTypeToAgentRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
          const agentToRequestTypeRelationshipRecords = await Promise.resolve(listAgentToRequestTypeRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });

          const deleteRequestTypeToAgentRelationshipRecordPromise = requestTypeToAgentRelationshipRecords.map(async ({ id, source, target }) => {
            if(source === rowValues.requestTypeId && target === agentRecordId) {
              await Promise.resolve(sunshineApi.deleteRelationshipRecord({ id }));
            }
          });

          const deleteAgentToRequestTypeRelationshipRecordPromise = agentToRequestTypeRelationshipRecords.map(async ({ id, source, target }) => {
            if(source === agentRecordId && target === rowValues.requestTypeId) {
              await Promise.resolve(sunshineApi.deleteRelationshipRecord({ id }));
            }
          })

          await Promise.all(deleteRequestTypeToAgentRelationshipRecordPromise);
          await Promise.all(deleteAgentToRequestTypeRelationshipRecordPromise);
        }
      }); 

      await Promise.all(createNewApproverRecordPromise);
      await Promise.all(deleteNonExistingApproverPromise);

      clickedElem.parent().siblings('td:has(input.approvers-list)').children('input.approvers-list').val(rowValues.approversList.join(', '));
      clickedElem.parent().siblings('td:has(input.approvers-list)').children('span').html(rowValues.approversList.join(', '));
      clickedElem.siblings('a').addBack().addClass('uk-hidden');
      clickedElem.siblings('a.edit-record').removeClass('uk-hidden');
      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully updated list of approvers' });
      generalFunctions.hideButtonSpinner(clickedElem.parent());
      generalFunctions.disableRowEditor(clickedElem);
    });

    $('table.fulfillers a.update-record').on('click', async () => {
      const clickedElem = $(event.currentTarget);
      generalFunctions.showButtonSpinner(clickedElem.parent());
      const rowValues = generalFunctions.getTaskTypeRowValues(clickedElem.parents('tr'));

      const searchUsersPromise = sunshineApi.sendApiRequest({ url: '/api/v2/search.json?query=type:user%20role:agent%20role:admin', method: 'GET' });
      const listOldFulfillersPromise = sunshineApi.listRelatedObjectRecords({ id: rowValues.taskTypeId, relationship_type: 'task_type_to_agent' });

      const agents = await Promise.resolve(searchUsersPromise).then(({ results }) => { return results }, (err) => { return err });
      const oldFulfillersList = await Promise.resolve(listOldFulfillersPromise).then(({ data }) => { return data }, (err) => { return err });
      const newFulfillersList = rowValues.fulfillersList;

      const createNewFulfillerRecordPromise = newFulfillersList.map(async (newFulfillerEmail) => {
        console.log('oldFulfillersList.map');
        let agentEmail = oldFulfillersList.find(({ attributes: { email }}) => {
          return email === newFulfillerEmail
        });

        if(!agentEmail) {
          const agent = agents.find(({ email }) => {
            return email === newFulfillerEmail
          });

          if(!agent) {
            return;
          }

          const agentObjectRecordPayload = {
            data: {
              type: 'agent',
              external_id: agent.id,
              attributes: {
                name: agent.name,
                email: agent.email
              }
            }
          };
          
          const newAgentObjectRecord = await Promise.resolve(sunshineApi.setObjectRecordByExternalId({ payload: agentObjectRecordPayload })).then(({ data }) => { return data }, (err) => { return err });
          
          const taskTypeToAgentPayload = {
            data: {
              relationship_type: 'task_type_to_agent',
              source: rowValues.taskTypeId,
              target: newAgentObjectRecord.id
            }
          };

          const createTaskTypeToAgentRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: taskTypeToAgentPayload });

          const agentToTaskTypePayload = {
            data: {
              relationship_type: 'agent_to_task_type',
              source: newAgentObjectRecord.id,
              target: rowValues.taskTypeId
            }
          };

          const createAgentToTaskTypeRelationshipRecordPromise = sunshineApi.createRelationshipRecord({ payload: agentToTaskTypePayload });

          await Promise.resolve(createTaskTypeToAgentRelationshipRecordPromise);
          await Promise.resolve(createAgentToTaskTypeRelationshipRecordPromise);
        }
      });  

      const deleteNonExistingFulfillerPromise = oldFulfillersList.map(async ({ id: agentRecordId, attributes: { email }}) => {
        let agentEmail = newFulfillersList.find((oldFulfillerEmail) => {
          return email === oldFulfillerEmail
        });

        if(!agentEmail) {
          console.log(`${email} does not exist anymore!`);

          const listTaskTypeToAgentRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByType({ relationship_type: 'task_type_to_agent' });
          const listAgentToTaskTypeRelationshipRecordsPromise = sunshineApi.listRelationshipRecordsByType({ relationship_type: 'agent_to_task_type' });

          const taskTypeToAgentRelationshipRecords = await Promise.resolve(listTaskTypeToAgentRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });
          const agentToTaskTypeRelationshipRecords = await Promise.resolve(listAgentToTaskTypeRelationshipRecordsPromise).then(({ data }) => { return data }, (err) => { return err });

          const deleteTaskTypeToAgentRelationshipRecordPromise = taskTypeToAgentRelationshipRecords.map(async ({ id, source, target }) => {
            if(source === rowValues.taskTypeId && target === agentRecordId) {
              await Promise.resolve(sunshineApi.deleteRelationshipRecord({ id }));
            }
          });

          const deleteAgentToTaskTypeRelationshipRecordPromise = agentToTaskTypeRelationshipRecords.map(async ({ id, source, target }) => {
            if(source === agentRecordId && target === rowValues.taskTypeId) {
              await Promise.resolve(sunshineApi.deleteRelationshipRecord({ id }));
            }
          })

          await Promise.all(deleteTaskTypeToAgentRelationshipRecordPromise);
          await Promise.all(deleteAgentToTaskTypeRelationshipRecordPromise);
        }
      }); 

      await Promise.all(createNewFulfillerRecordPromise);
      await Promise.all(deleteNonExistingFulfillerPromise);

      clickedElem.parent().siblings('td:has(input.fulfillers-list)').children('input.fulfillers-list').val(rowValues.fulfillersList.join(', '));
      clickedElem.parent().siblings('td:has(input.fulfillers-list)').children('span').html(rowValues.fulfillersList.join(', '));
      clickedElem.siblings('a').addBack().addClass('uk-hidden');
      clickedElem.siblings('a.edit-record').removeClass('uk-hidden');
      generalFunctions.removeAlertMessages();
      generalFunctions.generateAlertMessage({ type: 'success', msg: 'Successfully updated list of fulfillers' });
      generalFunctions.hideButtonSpinner(clickedElem.parent());
      generalFunctions.disableRowEditor(clickedElem);
    });
  },

  refreshTables: async ({ requestTypeRecords, taskTypeRecords }) => {
    $('.config table.approvers tbody, .config table.fulfillers tbody').empty();
    const refreshApproversTablePromise = generalFunctions.refreshApproversTable({ requestTypeRecords });
    const refreshFulfillersTablePromise = generalFunctions.refreshFulfillersTable({ taskTypeRecords });
    
    await Promise.resolve(refreshApproversTablePromise);
    await Promise.resolve(refreshFulfillersTablePromise);
  },

  refreshApproversTable: async ({ requestTypeRecords }) => {
    const listTicketFormsPromise = generalFunctions.listTicketForms();
    const listTicketFieldsPromise = generalFunctions.listTicketFields();

    const ticketForms = await Promise.resolve(listTicketFormsPromise);
    const ticketFields = await Promise.resolve(listTicketFieldsPromise);

    const createRequestTypeRowsPromises = requestTypeRecords.map(async ({ id, attributes: { name, ticket_form_id, ticket_field_id }}) => {
      let relatedAgentsToRequestType = await sunshineApi.listRelatedObjectRecords({ id, relationship_type: 'request_type_to_agent' }).then(({ data }) => { return data }, (error) => { return error });
      let approversEmailList = [];
      relatedAgentsToRequestType.map(({ attributes: { email }}) => {
        approversEmailList.push(email);
      });

      const approversStr = approversEmailList.join(', ');
      let tableRow = `<tr data-request-type-id=${id}><td><span class="request-type-name">${name}</span></td>\
      <td>${htmlTemplates.ticketFormSelect}</td>\
      <td>${htmlTemplates.ticketFieldSelect}</td>\
      <td><input class="uk-input uk-hidden approvers-list" type="email" value="${approversStr}" placeholder="aong@zendesk.com, user@example.com, admin@test.com" />\
      <span>${approversStr}</span></td><td>${htmlTemplates.editButton + htmlTemplates.updateButton + htmlTemplates.cancelButton + htmlTemplates.spinner}</td></tr>`;
      $('.config table.approvers tbody').append(tableRow);

      generalFunctions.refreshTicketFormSelect({ rowId: id, ticketForms, currentTicketFormId: ticket_form_id });
      generalFunctions.refreshTicketFieldSelect({ rowId: id, ticketForms, currentTicketFormId: ticket_form_id, ticketFields, currentTicketField: ticket_field_id });
    });

    await Promise.all(createRequestTypeRowsPromises);
  },

  refreshFulfillersTable: async ({ taskTypeRecords }) => {
    const createTaskTypeRowsPromises = taskTypeRecords.map(async ({ id, attributes: { name, ticket_form_id, ticket_field_id }}) => {
      let relatedAgentsToTaskType = await sunshineApi.listRelatedObjectRecords({ id, relationship_type: 'task_type_to_agent' }).then(({ data }) => { return data }, (error) => { return error });
      let fulfillersEmailList = [];
      relatedAgentsToTaskType.map(({ attributes: { email }}) => {
        fulfillersEmailList.push(email);
      });

      const fulfillersStr = fulfillersEmailList.join(', ');
      let tableRow = `<tr data-task-type-id=${id}><td><span class="task-type-name">${name}</span></td>\
      <td><input class="uk-input uk-hidden fulfillers-list" type="email" value="${fulfillersStr}" placeholder="aong@zendesk.com, user@example.com, admin@test.com" />\
      <span>${fulfillersStr}</span></td><td>${htmlTemplates.editButton + htmlTemplates.updateButton + htmlTemplates.cancelButton + htmlTemplates.spinner}</td></tr>`;
      $('.config table.fulfillers tbody').append(tableRow);
    });

    
    await Promise.all(createTaskTypeRowsPromises);
  },

  refreshTicketFormSelect: ({ rowId, ticketForms, currentTicketFormId }) => {
    $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-form`).empty();
    $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-form`).append('<option>-</option>');

    ticketForms.map(({ id, name, active, ticket_field_ids }) => {
      const selected = id === currentTicketFormId ? 'selected' : '';

      if(active) {
        const option = $(`<option value=${id} ${selected}>${name}</option>`).data('children-ticket-field-ids', ticket_field_ids);
        $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-form`).append(option);
      }
    });
  },

  refreshTicketFieldSelect: async ({ rowId, ticketForms, currentTicketFormId, ticketFields, currentTicketField  }) => {
    $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-field`).empty();
    $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-field`).append('<option>-</option>');

    ticketForms.map(({ id, ticket_field_ids: ticketFieldsIds }) => {
      if(id === currentTicketFormId) {
        ticketFieldsIds.map((ticketFieldId) => {
          const ticketField = ticketFields.find((element) => {
            return element.id === ticketFieldId && element.active;
          });

          const selected = ticketField.id === currentTicketField ? 'selected' : '';

          const option = $(`<option value=${ticketField.id} ${selected}>${ticketField.title}</option>`);
          $(`.config table.approvers tbody tr[data-request-type-id="${rowId}"] select.ticket-field`).append(option);
        });
      }
    });
  },

  listTicketForms: async () => {
    const settings = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/v2/ticket_forms.json',
      method: 'GET'
    };

    const ticketForms = await sunshineApi.sendApiRequest(settings).then(({ ticket_forms }) => { return ticket_forms }, (error) => { return error });
    return ticketForms;
  },

  listTicketFields: async () => {
    const settings = {
      headers: {
        'Content-Type': 'application/json'
      },
      url: '/api/v2/ticket_fields.json',
      method: 'GET'
    };

    const ticketFields = await sunshineApi.sendApiRequest(settings).then(({ ticket_fields }) => { return ticket_fields }, (error) => { return error });
    return ticketFields;
  }
};

const init = async () => {
  // General
  const jqueryInit = await Promise.resolve($());
  client = await Promise.resolve(ZAFClient.init());
  const appRegistered = await Promise.resolve(client.on('app.registered'));
  let currentUser = await Promise.resolve(client.get('currentUser'));
  currentUser = currentUser.currentUser;

  generalFunctions.showMainSpinner();

  let listRequestTypeRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'request_type' });
  let listTaskTypeRecordsPromise = sunshineApi.listObjectRecordsByType({ object_type: 'task_type' });

  let requestTypeRecords = await listRequestTypeRecordsPromise.then(({ data }) => { return data }, (error) => { return error });
  let taskTypeRecords = await listTaskTypeRecordsPromise.then(({ data }) => { return data }, (error) => { return error });
  
  if(requestTypeRecords.length < 1) {
    const createRequestTypeRecordsPromises = sunshineConfig.defaultObjectRecords.request_types.map((requestType) => {
      return sunshineApi.createObjectRecord({ payload: requestType });
    });

    const newRequestTypeRecords = await Promise.all(createRequestTypeRecordsPromises);
    requestTypeRecords = [];
    newRequestTypeRecords.map(({ data }) => {
      requestTypeRecords.push(data);
    });
  }

  if(taskTypeRecords.length < 1) {
    const createTaskTypeRecordsPromises = sunshineConfig.defaultObjectRecords.task_types.map((taskType) => {
      return sunshineApi.createObjectRecord({ payload: taskType });
    });

    const newTaskTypeRecords = await Promise.all(createTaskTypeRecordsPromises);
    taskTypeRecords = [];
    newTaskTypeRecords.map(({ data }) => {
      taskTypeRecords.push(data);
    });
  }

  $('.config table.approvers, .config table.fulfillers').append('<tbody></tbody>');
  await generalFunctions.refreshTables({ requestTypeRecords, taskTypeRecords });
  generalFunctions.registerEventListeners();
  generalFunctions.hideMainSpinner();
}

init();