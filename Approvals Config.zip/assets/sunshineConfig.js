const sunshineConfig = {
  defaultObjectRecords: {
    request_types: [
      {
        data: {
          type: 'request_type',
          attributes: {
            name: 'Software Request',
            ticket_form_id: 0,
            ticket_field_id: 0,
          }
        }
      },
      {
        data: {
          type: 'request_type',
          attributes: {
            name: 'Hardware Request',
            ticket_form_id: 0,
            ticket_field_id: 0,
          }
        }
      },
      {
        data: {
          type: 'request_type',
          attributes: {
            name: 'Standard Change',
            ticket_form_id: 0,
            ticket_field_id: 0,
          }
        }
      },
      {
        data: {
          type: 'request_type',
          attributes: {
            name: 'Normal Change',
            ticket_form_id: 0,
            ticket_field_id: 0,
          }
        }
      },
      {
        data: {
          type: 'request_type',
          attributes: {
            name: 'Emergency Change',
            ticket_form_id: 0,
            ticket_field_id: 0,
          }
        }
      },
    ],
    task_types: [
      {
        data: {
          type: 'task_type',
          attributes: {
            name: 'Fulfillment'
          }
        }
      },
      {
        data: {
          type: 'task_type',
          attributes: {
            name: 'Implement'
          }
        }
      },
      {
        data: {
          type: 'task_type',
          attributes: {
            name: 'Review'
          }
        }
      }
    ]
  }
};