# Approvals Configuration

Lets you specify the approvers for each type of request